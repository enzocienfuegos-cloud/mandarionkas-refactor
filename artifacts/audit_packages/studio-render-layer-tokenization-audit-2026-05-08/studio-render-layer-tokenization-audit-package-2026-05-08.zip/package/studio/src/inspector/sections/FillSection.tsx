import { ColorControl } from '../../shared/ui/ColorControl';
import { useEffect, useMemo, useState } from 'react';
import { listAssets } from '../../repositories/asset';
import { subscribeToAssetLibraryChanges } from '../../repositories/asset/events';
import type { AssetRecord } from '../../assets/types';
import type { WidgetNode } from '../../domain/document/types';
import { useUiActions, useWidgetActions } from '../../hooks/use-studio-actions';
import { usePlatformSnapshot } from '../../platform/runtime';
import { Button } from '../../shared/ui/Button';
import { getCapability } from '../../widgets/registry/widget-definition';
import { getWidgetDefinition } from '../../widgets/registry/widget-registry';
import { badgeStateFromInheritance, useWidgetInheritance, type InheritanceBadgeState } from '../use-widget-inheritance';

function hasAny(keys: Set<string>, targets: string[]): boolean {
  return targets.some((target) => keys.has(target));
}

export function FillSection({ widget }: { widget: WidgetNode }): JSX.Element {
  const widgetActions = useWidgetActions();
  const uiActions = useUiActions();
  const platform = usePlatformSnapshot();
  const {
    baseWidget,
    inheritedSharedBaseWidget,
    isMasterVariant,
    isSharedLayerBase,
    isSharedLayerClone,
    localVariantStyleOverrideKeys,
    localVariantPropsOverrideKeys,
    localSceneStyleOverrideKeys,
    localScenePropsOverrideKeys,
  } = useWidgetInheritance(widget);
  const [assets, setAssets] = useState<AssetRecord[]>([]);
  const definition = useMemo(() => getWidgetDefinition(widget.type), [widget.type]);
  const acceptsVideoAsset = Boolean(getCapability(definition, 'acceptsVideoAsset'));
  const acceptsImageAsset = Boolean(getCapability(definition, 'acceptsImageAsset'));
  const supportsAssetSwap = acceptsVideoAsset || acceptsImageAsset;

  useEffect(() => {
    if (!platform.session.isAuthenticated || !platform.session.sessionId) {
      setAssets([]);
      return;
    }
    let cancelled = false;
    const syncAssets = () => {
      void listAssets()
        .then((records) => {
          if (!cancelled) setAssets(records);
        })
        .catch(() => {
          if (!cancelled) setAssets([]);
        });
    };
    syncAssets();
    const unsubscribe = subscribeToAssetLibraryChanges(syncAssets);
    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, [platform.session.isAuthenticated, platform.session.sessionId]);

  const eligibleAssets = useMemo(
    () => assets.filter((asset) => (acceptsVideoAsset ? asset.kind === 'video' : acceptsImageAsset ? asset.kind === 'image' : false)),
    [acceptsImageAsset, acceptsVideoAsset, assets],
  );
  const resetTarget = isSharedLayerClone ? inheritedSharedBaseWidget : baseWidget;
  const hasFillSectionOverride = hasAny(localVariantStyleOverrideKeys, ['backgroundColor', 'accentColor', 'fit'])
    || hasAny(localVariantPropsOverrideKeys, ['src', 'assetId', 'alt', 'posterSrc'])
    || hasAny(localSceneStyleOverrideKeys, ['backgroundColor', 'accentColor', 'fit'])
    || hasAny(localScenePropsOverrideKeys, ['src', 'assetId', 'alt', 'posterSrc']);

  function renderInheritanceBadge(state: InheritanceBadgeState): JSX.Element | null {
    if (state === 'none') return null;
    if (state === 'local') return <span className="inspector-override-badge is-local">✱</span>;
    if (state === 'shared') return <span className="inspector-override-badge is-shared">S</span>;
    return <span className="inspector-override-badge is-master">M</span>;
  }

  function resetToMaster(): void {
    if (!resetTarget) return;
    widgetActions.updateWidgetStyle(widget.id, {
      backgroundColor: resetTarget.style.backgroundColor,
      accentColor: resetTarget.style.accentColor,
      fit: resetTarget.style.fit,
    });
    widgetActions.updateWidgetProps(widget.id, {
      src: resetTarget.props.src,
      assetId: resetTarget.props.assetId,
      alt: resetTarget.props.alt,
      posterSrc: resetTarget.props.posterSrc,
    });
  }

  return (
    <section className="section section-premium">
      <div className="section-heading-row">
        <div>
          <h3>Fill / colors</h3>
          {isSharedLayerClone ? (
            <small className="muted">
              Visual fill and linked assets inherit from the shared base layer unless this scene overrides them locally.
            </small>
          ) : isSharedLayerBase ? (
            <small className="muted">
              Fill and linked assets edited here propagate to every scene using this shared layer unless a scene has a local exception.
            </small>
          ) : !isMasterVariant ? (
            <small className="muted">
              Visual fill, linked assets, and fit behavior inherit from the master size unless this size overrides them locally.
            </small>
          ) : null}
        </div>
        {(isSharedLayerClone || !isMasterVariant) && hasFillSectionOverride ? (
          <Button variant="ghost" size="sm" className="subtle-action" onClick={resetToMaster}>
            {isSharedLayerClone ? 'Reset scene override' : 'Reset to master'}
          </Button>
        ) : null}
      </div>
      <div className="fields-grid">
        <ColorControl
          label="Background"
          labelAccessory={renderInheritanceBadge(badgeStateFromInheritance({
            sceneLocal: localSceneStyleOverrideKeys.has('backgroundColor'),
            variantLocal: localVariantStyleOverrideKeys.has('backgroundColor'),
            sharedClone: isSharedLayerClone,
            isMasterVariant,
          })) ?? undefined}
          value={String(widget.style.backgroundColor ?? '#1f2937')}
          fallback="#1f2937"
          onChange={(value) => widgetActions.updateWidgetStyle(widget.id, { backgroundColor: value })}
        />
        <ColorControl
          label="Accent"
          labelAccessory={renderInheritanceBadge(badgeStateFromInheritance({
            sceneLocal: localSceneStyleOverrideKeys.has('accentColor'),
            variantLocal: localVariantStyleOverrideKeys.has('accentColor'),
            sharedClone: isSharedLayerClone,
            isMasterVariant,
          })) ?? undefined}
          value={String(widget.style.accentColor ?? '#f59e0b')}
          fallback="#f59e0b"
          onChange={(value) => widgetActions.updateWidgetStyle(widget.id, { accentColor: value })}
        />
      </div>
      {supportsAssetSwap ? (
        <div className="field-stack section-offset-top">
          <div>
            <label className="inspector-field-label">
              <span>{acceptsVideoAsset ? 'Video source' : 'Image source'}</span>
              {renderInheritanceBadge(badgeStateFromInheritance({
                sceneLocal: localScenePropsOverrideKeys.has('src'),
                variantLocal: localVariantPropsOverrideKeys.has('src'),
                sharedClone: isSharedLayerClone,
                isMasterVariant,
              }))}
            </label>
            <input value={String(widget.props.src ?? '')} onChange={(event) => widgetActions.updateWidgetProps(widget.id, { src: event.target.value })} placeholder={acceptsVideoAsset ? 'https://.../video.mp4' : 'https://.../image.jpg'} />
          </div>
          <div>
            <label className="inspector-field-label">
              <span>Asset library</span>
              {renderInheritanceBadge(badgeStateFromInheritance({
                sceneLocal: hasAny(localScenePropsOverrideKeys, ['assetId', 'alt']),
                variantLocal: hasAny(localVariantPropsOverrideKeys, ['assetId', 'alt']),
                sharedClone: isSharedLayerClone,
                isMasterVariant,
              }))}
            </label>
            <div className="asset-inline-actions">
              <select value={String(widget.props.assetId ?? '')} onChange={(event) => {
              const assetId = event.target.value;
              const asset = eligibleAssets.find((item) => item.id === assetId);
              widgetActions.updateWidgetProps(
                widget.id,
                asset
                  ? { assetId: asset.id, src: asset.src, alt: asset.name, posterSrc: asset.posterSrc ?? widget.props.posterSrc }
                  : { assetId: '', src: '' },
              );
            }}>
              <option value="">No linked asset</option>
              {eligibleAssets.map((asset) => <option key={asset.id} value={asset.id}>{asset.name}</option>)}
            </select>
              <Button size="sm" className="left-button compact-action" onClick={() => uiActions.setLeftTab('assets')}>Open library</Button>
            </div>
          </div>
          {acceptsVideoAsset ? <div>
            <label className="inspector-field-label">
              <span>Poster source</span>
              {renderInheritanceBadge(badgeStateFromInheritance({
                sceneLocal: localScenePropsOverrideKeys.has('posterSrc'),
                variantLocal: localVariantPropsOverrideKeys.has('posterSrc'),
                sharedClone: isSharedLayerClone,
                isMasterVariant,
              }))}
            </label>
            <input value={String(widget.props.posterSrc ?? '')} onChange={(event) => widgetActions.updateWidgetProps(widget.id, { posterSrc: event.target.value })} placeholder="https://.../poster.jpg" />
          </div> : null}
          {acceptsImageAsset ? <div>
            <label className="inspector-field-label">
              <span>Fit</span>
              {renderInheritanceBadge(badgeStateFromInheritance({
                sceneLocal: localSceneStyleOverrideKeys.has('fit'),
                variantLocal: localVariantStyleOverrideKeys.has('fit'),
                sharedClone: isSharedLayerClone,
                isMasterVariant,
              }))}
            </label>
            <select value={String(widget.style.fit ?? 'cover')} onChange={(event) => widgetActions.updateWidgetStyle(widget.id, { fit: event.target.value })}>
              <option value="cover">cover</option>
              <option value="contain">contain</option>
            </select>
          </div> : null}
        </div>
      ) : null}
    </section>
  );
}
