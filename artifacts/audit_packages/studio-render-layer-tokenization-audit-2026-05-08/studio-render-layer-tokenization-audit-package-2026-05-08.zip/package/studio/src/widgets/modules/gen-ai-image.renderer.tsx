// render-tokenized: brand/theme split enforced by lint-color-literals.mjs
import { useState, type CSSProperties } from 'react';
import type { WidgetNode } from '../../domain/document/types';
import type { RenderContext } from '../../canvas/stage/render-context';
import { clamp, getAccent, moduleBody, moduleHeader, moduleShell, renderCollapsedIfNeeded } from './shared-styles';

const genAiPromptStyle: CSSProperties = {
  fontSize: 12,
  opacity: 0.78,
};

const genAiGridStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(2, 1fr)',
  gap: 8,
};

function buildGenAiVariationStyle(accent: string, selected: boolean): CSSProperties {
  return {
    height: 54,
    borderRadius: 10,
    border: selected ? `2px solid ${accent}` : '1px solid var(--white-a-12)',
    background: `linear-gradient(135deg, ${accent}${selected ? '44' : '22'}, var(--white-a-08))`,
    color: 'inherit',
    fontWeight: 700,
  };
}

function GenAiImageModuleRenderer({ node, ctx }: { node: WidgetNode; ctx: RenderContext }): JSX.Element {
  const accent = getAccent(node);
  const prompt = String(node.props.prompt ?? 'Luxury portrait with warm light');
  const variationCount = clamp(Number(node.props.variationCount ?? 4), 2, 6);
  const [selected, setSelected] = useState(0);

  return (
    <div style={moduleShell(node, ctx)}>
      <div style={moduleHeader(node)}>{String(node.props.title ?? node.name)}</div>
      <div style={moduleBody}>
        <div style={genAiPromptStyle}>{prompt}</div>
        <div style={genAiGridStyle}>
          {Array.from({ length: variationCount }).map((_, index) => (
            <button
              key={index}
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                setSelected(index);
                ctx.triggerWidgetAction('click');
              }}
              style={buildGenAiVariationStyle(accent, selected === index)}
            >
              {`v${index + 1}`}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export function renderGenAiImageStage(node: WidgetNode, ctx: RenderContext): JSX.Element {
  const collapsed = renderCollapsedIfNeeded(node, ctx);
  if (collapsed) return collapsed;
  return <GenAiImageModuleRenderer node={node} ctx={ctx} />;
}
