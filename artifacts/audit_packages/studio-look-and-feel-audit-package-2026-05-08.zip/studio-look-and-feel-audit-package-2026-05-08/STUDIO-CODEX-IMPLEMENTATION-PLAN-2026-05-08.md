# SMX Studio — Codex Implementation Plan (2026-05-08)

> **Audiencia:** Codex actuando como senior frontend en `apps/studio`.
> **Objetivo:** ejecutar la deuda visual y de escalabilidad detectada en `STUDIO-UX-AUDIT-2026-05-08.md` sin romper builds ni guardrails de tests.
> **Modo de trabajo:** **un sprint = un grupo de tickets**. No mezclar grupos. Tras cada grupo: `pnpm typecheck:web && pnpm test:web && pnpm build:web` debe pasar. **Si un test rompe, NO refactorizar el test — entender la regresión visual o de comportamiento primero**.

---

## 0. Reglas de oro (no negociables)

1. **No tocar contratos del dominio.** `WidgetDefinition`, `StudioState`, comandos, reducers, store, `RenderContext`, exporters: intocables salvo donde el ticket lo diga explícitamente. Si Codex cree necesario tocar un contrato, parar y preguntar.
2. **Backwards compat absoluto.** Cada widget existente (31 definitions) debe seguir funcionando idéntico antes y después de cada ticket. Los snapshots/architecture tests deben pasar.
3. **Nada de Tailwind, Radix, HeadlessUI, MUI, ChakraUI, styled-components, emotion.** Esto se hace **vanilla CSS + CSS variables + componentes React propios** sobre `theme.css`. Discutirlo después si hace falta.
4. **Cero downtime visual.** Cada PR debe poder deployearse aislado. Las migraciones largas (ej.: iconos) van por sub-PRs.
5. **No introducir `!important`.** El que existe (4 instancias) se elimina cuando se llegue a su sección.
6. **Convenciones de naming CSS:** BEM ligero — `.block`, `.block__elem`, `.block--modifier`, estados con `is-` (`.is-active`, `.is-selected`, `.is-dragging`). Nada de tailwind-like utilities en este iteración.
7. **Cada ticket trae un acceptance check** que se ejecuta antes de cerrar.
8. **Lint stylelint** se introduce como parte del SPRINT 1 y se mantiene verde de ahí en adelante.

---

## 1. Roadmap (orden obligatorio)

```
SPRINT 1 — Foundations: tokens + lint + split CSS         [BLOQUEANTE]
SPRINT 2 — Icon system + lucide migration                  [BLOQUEANTE para sprint 4]
SPRINT 3 — Primitivos UI (Button, IconButton, Tabs, …)     [BLOQUEANTE para sprint 5+]
SPRINT 4 — Shell: tokens dimensionales + persistencia      [INDEPENDIENTE]
SPRINT 5 — Inspector contract-driven document tabs         [DEPENDE 3]
SPRINT 6 — Capability flags en WidgetDefinition            [DEPENDE 3]
SPRINT 7 — Widget Library con thumbnails                   [DEPENDE 2, 3]
SPRINT 8 — Edit-mode wireframe rendering                   [DEPENDE 6]
SPRINT 9 — Story Flow visual canvas                        [DEPENDE 3]
SPRINT 10 — Layers panel decision (eliminar o outline)     [DEPENDE 3]
SPRINT 11 — Polish: TopBar density, tooltips, toasts, a11y [DEPENDE 3]
```

Cada sprint = 1 PR (idealmente). Si un PR pasa de ~600 LoC netos, partir.

---

## SPRINT 1 — Foundations: tokens + split CSS + stylelint

### Ticket S1-T1 — Tokens completos en `theme.css`
**Objetivo:** convertir `theme.css` en la única fuente de verdad para colores, espaciado, radios, tipografía, motion, sombras, z-index, surfaces.

**Acciones:**

1. Reemplazar el bloque `:root { … }` de `src/shared/theme.css` por:

```css
:root {
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  color-scheme: dark;
  color: var(--text);
  background: var(--bg);
  line-height: 1.4;
  font-weight: 400;

  /* ── Surfaces & strokes (existentes, mantener nombres) ───────── */
  --bg: #111820;
  --panel: #18222d;
  --panel-2: #1f2c39;
  --panel-3: #253444;
  --stroke: #314658;
  --stroke-2: #45617c;
  --text: #eef3f8;
  --muted: #9db0c2;
  --accent: #f5a524;
  --accent-2: #27c286;
  --danger: #e26a6a;
  --warning: #e8b34a;
  --info: #6f8bff;

  /* ── Surface elevation (use semantically) ───────────────────── */
  --surface-1: #141d26; /* rails, footer */
  --surface-2: #16202a; /* topbar */
  --surface-3: #17212b; /* inspector */
  --surface-4: #1c2733; /* cards inside panels */
  --surface-5: #253444; /* hover state */

  /* ── Stage backdrops (used by .workspace-shell-backdrop-*) ──── */
  --stage-grid-a: rgba(255, 255, 255, 0.03);
  --stage-grid-b: rgba(255, 255, 255, 0.02);

  /* ── Spacing scale (4-px grid) ───────────────────────────────── */
  --space-0: 0;
  --space-1: 2px;
  --space-2: 4px;
  --space-3: 6px;
  --space-4: 8px;
  --space-5: 10px;
  --space-6: 12px;
  --space-7: 14px;
  --space-8: 16px;
  --space-9: 20px;
  --space-10: 24px;
  --space-11: 28px;
  --space-12: 32px;

  /* ── Radius scale ────────────────────────────────────────────── */
  --radius-xs: 4px;
  --radius-sm: 6px;
  --radius-md: 8px;
  --radius-lg: 10px;
  --radius-xl: 12px;
  --radius-2xl: 16px;
  --radius-pill: 999px;

  /* ── Font size scale ────────────────────────────────────────── */
  --font-size-2xs: 10px;
  --font-size-xs: 11px;
  --font-size-sm: 12px;
  --font-size-md: 13px;
  --font-size-lg: 14px;
  --font-size-xl: 16px;
  --font-size-2xl: 18px;
  --font-size-3xl: 20px;
  --font-size-display: 32px;

  /* ── Shadows ─────────────────────────────────────────────────── */
  --shadow-1: 0 1px 2px rgba(0, 0, 0, 0.16);
  --shadow-2: 0 4px 10px rgba(0, 0, 0, 0.18);
  --shadow-3: 0 8px 24px rgba(0, 0, 0, 0.20);
  --shadow-4: 0 14px 34px rgba(0, 0, 0, 0.24);
  --shadow-focus: 0 0 0 3px rgba(245, 165, 36, 0.18);
  --shadow-focus-keyboard: 0 0 0 3px rgba(124, 92, 255, 0.20),
                           0 0 0 1px rgba(124, 92, 255, 0.65) inset;

  /* ── Motion ─────────────────────────────────────────────────── */
  --motion-fast: 120ms;
  --motion-base: 160ms;
  --motion-slow: 220ms;
  --motion-ease: cubic-bezier(0.2, 0.8, 0.2, 1);

  /* ── Z-index scale (USE ONLY THESE) ─────────────────────────── */
  --z-base: 0;
  --z-raised: 100;
  --z-sticky: 200;
  --z-floating: 400;
  --z-popover: 800;
  --z-modal: 1200;
  --z-toast: 1600;
  --z-top: 2000;

  /* ── Shell dimensions (resizable, persisted) ────────────────── */
  --shell-top-h: 64px;
  --shell-left-w: 288px;
  --shell-right-w: 328px;
  --shell-bottom-h: 260px;
  --shell-left-w-min: 200px;
  --shell-left-w-max: 520px;
  --shell-right-w-min: 280px;
  --shell-right-w-max: 520px;
  --shell-bottom-h-min: 160px;
  --shell-bottom-h-max: 520px;

  /* ── Component sizes ────────────────────────────────────────── */
  --control-h-sm: 28px;
  --control-h-md: 32px;
  --control-h-lg: 36px;
  --control-h-xl: 42px;
  --icon-size-sm: 14px;
  --icon-size-md: 18px;
  --icon-size-lg: 22px;
}
```

2. Actualizar las reglas globales que vienen tras `:root {}` para que usen los tokens (ej.: `button { min-height: var(--control-h-lg); border-radius: var(--radius-xl); padding: var(--space-4) var(--space-6); transition: … var(--motion-base) var(--motion-ease); }`).

**Acceptance check:**
- `theme.css` no contiene colores hex/rgba sueltos fuera del bloque `:root`.
- Visualmente, el editor luce idéntico (es una refactorización de tokens, no de estilo).
- `pnpm typecheck:web && pnpm build:web` OK.

---

### Ticket S1-T2 — Partir `layout.css` por dominio

**Estructura final:**

```
src/shared/styles/
  index.css            <- @import * en orden
  reset.css            <- box-sizing, margin reset (existente)
  base.css             <- button, input, label, select, textarea (existente theme.css extendido)
  shell.css            <- .studio-shell, .top-bar, .left-rail, .workspace, .right-inspector, .bottom-timeline, collapsed tabs
  topbar.css           <- top-bar-*, top-actions-cluster, top-back-button
  left-rail.css        <- left-rail*, left-tab-bar, left-button, left-card, layer-row, widget-grid, chip-row
  inspector.css        <- right-inspector, inspector-shell, inspector-hero, inspector-tabs, section-premium, inspector-accordion, fields-grid
  timeline.css         <- bottom-timeline, timeline-*, ruler-*, playhead-overlay
  stage.css            <- workspace-shell, workspace-toolbar, stage-*, selection-*, stage-canvas-quick-panel
  asset-library.css    <- asset-browser-*, asset-folder-*, asset-upload-progress-*
  platform.css         <- platform-login-*, workspace-hub-*, agency-shell-*
  utilities.css        <- .pill, .meta-line, .field-stack, .checkbox-row, .row-between, .row-end, .stack-sm, .stack-md, .tile-card
```

**Reglas:**
- **CADA SELECTOR APARECE EXACTAMENTE UNA VEZ.** Si Codex encuentra un selector duplicado, consolidar en un único bloque y resolver el conflicto a mano (la última definición existente es la canónica salvo que rompa visualmente).
- Reemplazar todos los hex/rgba de los archivos resultantes por los tokens correspondientes. Excepción: rgbas con alpha intermedio que no tengan token todavía → crearlos como `--bg-overlay-*` en `theme.css`.
- Reemplazar todos los `z-index: NUMBER` por `z-index: var(--z-*)`.
- Reemplazar todos los `border-radius` por `var(--radius-*)`.
- Reemplazar todos los `padding/margin/gap` por `var(--space-*)`.
- Reemplazar todos los `font-size` por `var(--font-size-*)`.
- Reemplazar todos los `transition` por `… var(--motion-base) var(--motion-ease)`.
- Eliminar los 4 `!important` documentando por qué (commit message).
- Mantener `layout.css` como archivo SHIM temporal con `@import './styles/index.css';` para no romper imports existentes.

**Acceptance check:**
- `wc -l src/shared/styles/*.css` cada archivo < 800 líneas.
- `grep -rE "^\.[a-zA-Z][a-zA-Z0-9_-]*[^,{]+\{" src/shared/styles/ | sort | uniq -d` retorna vacío (cero duplicados).
- `grep -rE "z-index:\s*[0-9]" src/shared/styles/` retorna vacío.
- `grep -rE "!important" src/shared/styles/` retorna vacío.
- Snapshot tests `architecture/*` y `smoke/*` pasan sin cambios.
- Diff visual zero (sólo refactor).

---

### Ticket S1-T3 — Stylelint guardrails

**Acción:**

1. Añadir a `apps/studio/package.json` devDeps: `stylelint`, `stylelint-config-standard`, `stylelint-declaration-strict-value`.
2. Crear `apps/studio/.stylelintrc.cjs`:

```js
module.exports = {
  extends: ['stylelint-config-standard'],
  plugins: ['stylelint-declaration-strict-value'],
  rules: {
    'no-duplicate-selectors': true,
    'declaration-no-important': true,
    'scale-unlimited/declaration-strict-value': [
      ['/color$/', 'fill', 'stroke', 'background-color', 'border-color', 'z-index', 'border-radius', 'font-size'],
      {
        ignoreValues: [
          'transparent', 'inherit', 'currentColor', 'none', 'unset', 'initial',
          '0', '1px solid', '/^var\\(/'
        ],
        message: 'Use a CSS custom property from theme.css instead of a literal value.'
      }
    ],
    /* permitir px solo en archivos de animaciones runtime; lo demás usa tokens */
    'declaration-property-value-disallowed-list': {
      'transition': ['/[0-9]+ms/', '/[0-9]\\.[0-9]+s/'] // forzar var(--motion-*)
    }
  },
  ignoreFiles: ['**/node_modules/**', 'dist/**']
};
```

3. Añadir scripts:
```json
{
  "scripts": {
    "lint:css": "stylelint 'src/**/*.css'",
    "lint:css:fix": "stylelint 'src/**/*.css' --fix"
  }
}
```

4. Integrar `lint:css` en CI (paso previo a `build`).

**Acceptance check:** `pnpm lint:css` exit 0 después de S1-T1 y S1-T2.

---

## SPRINT 2 — Icon system

### Ticket S2-T1 — Adoptar lucide-react

**Acción:**

1. Añadir `lucide-react` a `dependencies`.
2. Crear `src/shared/ui/icons/index.ts`:

```ts
/**
 * Single source of truth for icons.
 * Why we re-export instead of using lucide directly:
 *  - friendly mapping to our domain names (e.g. <SnapIcon /> not <Magnet />),
 *  - allows swapping lucide for an in-house set without touching consumers,
 *  - centralises default size + currentColor.
 */
import {
  ArrowLeft, ArrowRight, ChevronLeft, ChevronRight, ChevronUp, ChevronDown,
  X, Check, Plus, Minus, Trash2, Copy, Layers, Image as ImageIcon, Video,
  Type, Square, Circle, Eye, EyeOff, Lock, Unlock, Upload, Library,
  GripVertical, MoreHorizontal, Settings, Search, Play, Pause, SkipBack,
  SkipForward, Maximize2, Magnet, Ruler, Tags, Folder, FolderOpen, FilePlus,
  ArrowUpToLine, ArrowDownToLine, MousePointer2, Move, ZoomIn, ZoomOut,
  ChevronsLeft, ChevronsRight, Component
} from 'lucide-react';

export const Icon = {
  // navigation
  Back: ArrowLeft, Forward: ArrowRight,
  CollapseLeft: ChevronLeft, ExpandRight: ChevronRight,
  CollapseDown: ChevronDown, ExpandUp: ChevronUp,
  Close: X, Check, Add: Plus, Remove: Minus,
  // edit
  Delete: Trash2, Duplicate: Copy, Rename: Type,
  Visible: Eye, Hidden: EyeOff, Locked: Lock, Unlocked: Unlock,
  Layers, Group: Component,
  // assets
  Upload, Library, Image: ImageIcon, Video, Folder, FolderOpen, AssetNew: FilePlus,
  // canvas
  Move, Cursor: MousePointer2, ZoomIn, ZoomOut, Fit: Maximize2,
  Rulers: Ruler, Badges: Tags,
  // timeline
  Play, Pause, JumpStart: SkipBack, JumpEnd: SkipForward, Snap: Magnet,
  // structure
  DragHandle: GripVertical, More: MoreHorizontal, Settings, Search,
  LayerForward: ArrowUpToLine, LayerBackward: ArrowDownToLine,
  PanelLeftCollapse: ChevronsLeft, PanelRightCollapse: ChevronsRight,
  // shapes
  Square, Circle,
} as const;
```

3. Crear `src/shared/ui/icons/IconWrap.tsx`:

```tsx
import type { LucideIcon } from 'lucide-react';

type IconSize = 'sm' | 'md' | 'lg';

const SIZE_PX: Record<IconSize, number> = { sm: 14, md: 18, lg: 22 };

export function IconWrap({
  glyph: Glyph, size = 'md', strokeWidth = 1.6,
}: {
  glyph: LucideIcon; size?: IconSize; strokeWidth?: number;
}): JSX.Element {
  return <Glyph size={SIZE_PX[size]} strokeWidth={strokeWidth} aria-hidden="true" />;
}
```

**Acceptance check:** existe `Icon.Back`, `Icon.Visible`, etc., y tipo es `LucideIcon`.

---

### Ticket S2-T2 — Migrar TODOS los glyphs Unicode a iconos

**Inventario obligatorio (no omitir ninguno):**

| Archivo | Glyph actual | Reemplazo |
|---|---|---|
| `LeftTabBar.tsx` | `▦ ☰ ◫ ⇄ ⚙` | `Icon.Component, Icon.Layers, Icon.Library, Icon.Forward, Icon.Settings` |
| `LeftRail.tsx` | `‹` | `Icon.PanelLeftCollapse` |
| `RightInspector.tsx` | `›` | `Icon.PanelRightCollapse` |
| `StudioShell.tsx` | `▦ ‹ ⌃` | `Icon.Component, Icon.PanelLeftCollapse, Icon.CollapseDown` |
| `TopBar.tsx` | `←` | `Icon.Back` |
| `TopBarDocumentControls.tsx` | `← →` | `Icon.Back, Icon.Forward` |
| `StoryFlowSection.tsx` | `＋ ⧉ 🗑 ↳` | `Icon.Add, Icon.Duplicate, Icon.Delete, Icon.ExpandRight` |
| `AssetLibraryModal.tsx` | `▾ ▸ ✕ ▣` | `Icon.CollapseDown, Icon.ExpandRight, Icon.Close, Icon.Folder` |
| `ExportMenu.tsx` | `✓` | `Icon.Check` |
| `StageFloatingToolbar.tsx` | `⋮⋮ ▣ — ← → R B` | `Icon.DragHandle, Icon.Component, Icon.Remove, Icon.Back, Icon.Forward, Icon.Rulers, Icon.Badges` |
| `TimelineHeader.tsx` | `↕ ⏮ − + ⇄ ⌄ ⏸ ▶` | `Icon.DragHandle (rot 90°), Icon.JumpStart, Icon.Remove, Icon.Add, Icon.Snap, Icon.CollapseDown, Icon.Pause, Icon.Play` |
| `Stage.tsx` (quickpanel) | `∅` | dejar `null` con label "Transparent" + `Icon.Close` overlay |

Patrón para reemplazo (caso típico):
```diff
-<button className="ghost icon-button" title="Add scene">＋</button>
+<button className="ghost icon-button" title="Add scene" aria-label="Add scene">
+  <IconWrap glyph={Icon.Add} />
+</button>
```

**`StageSelectionToolbar.tsx`:** eliminar las funciones internas `EyeIcon`, `LockIcon`, etc., y usar `<IconWrap glyph={Icon.Visible} />` etc.

**Acceptance check:**
- `grep -rnE ">[^<]*[▦☰◫⇄⚙‹›⌃⌄✕✓◯●▶◀⏵⏸⧉🗑↕⏮⏭＋∅⋮▣]" src/` retorna vacío (excluyendo strings literales en docs/tests).
- Visual: cada lugar muestra el icono correcto, estable cross-OS.
- Tests visuales/snapshots actualizados.

---

## SPRINT 3 — Component primitives

### Ticket S3-T1 — `<Button>` y `<IconButton>`

`src/shared/ui/Button.tsx`:

```tsx
import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size = 'sm' | 'md' | 'lg';

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: Size;
  iconBefore?: ReactNode;
  iconAfter?: ReactNode;
  loading?: boolean;
};

export const Button = forwardRef<HTMLButtonElement, Props>(function Button(
  { variant = 'secondary', size = 'md', iconBefore, iconAfter, loading, disabled, className = '', children, ...rest }, ref) {
  return (
    <button
      ref={ref}
      className={`btn btn--${variant} btn--${size} ${loading ? 'is-loading' : ''} ${className}`.trim()}
      disabled={disabled || loading}
      {...rest}
    >
      {iconBefore ? <span className="btn__icon btn__icon--before">{iconBefore}</span> : null}
      {children ? <span className="btn__label">{children}</span> : null}
      {iconAfter ? <span className="btn__icon btn__icon--after">{iconAfter}</span> : null}
    </button>
  );
});
```

`src/shared/ui/IconButton.tsx`:

```tsx
import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';

type Variant = 'ghost' | 'solid' | 'danger';
type Size = 'sm' | 'md' | 'lg';

type Props = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> & {
  variant?: Variant;
  size?: Size;
  label: string;       // a11y, requerido
  icon: ReactNode;
  isActive?: boolean;
};

export const IconButton = forwardRef<HTMLButtonElement, Props>(function IconButton(
  { variant = 'ghost', size = 'md', label, icon, isActive, className = '', ...rest }, ref) {
  return (
    <button
      ref={ref}
      type="button"
      className={`icon-btn icon-btn--${variant} icon-btn--${size} ${isActive ? 'is-active' : ''} ${className}`.trim()}
      aria-label={label}
      aria-pressed={isActive}
      title={label}
      {...rest}
    >
      {icon}
    </button>
  );
});
```

CSS asociado `src/shared/styles/components.css` (importado en `index.css`):

```css
/* Button */
.btn { display: inline-flex; align-items: center; gap: var(--space-3); border-radius: var(--radius-xl); border: 1px solid rgba(120, 144, 168, 0.24); cursor: pointer; transition: background var(--motion-base) var(--motion-ease), border-color var(--motion-base) var(--motion-ease), transform var(--motion-base) var(--motion-ease), box-shadow var(--motion-base) var(--motion-ease); font-weight: 600; }
.btn--sm { min-height: var(--control-h-sm); padding: 0 var(--space-5); font-size: var(--font-size-xs); }
.btn--md { min-height: var(--control-h-lg); padding: 0 var(--space-6); font-size: var(--font-size-sm); }
.btn--lg { min-height: var(--control-h-xl); padding: 0 var(--space-8); font-size: var(--font-size-md); }
.btn--primary { background: linear-gradient(180deg, var(--accent-2), #1da774); color: #08110d; border-color: rgba(39,194,134,.32); box-shadow: var(--shadow-2); }
.btn--secondary { background: linear-gradient(180deg, var(--surface-5), #1c2934); color: var(--text); }
.btn--ghost { background: rgba(255,255,255,0.03); color: var(--text); }
.btn--ghost:hover { background: rgba(255,255,255,0.06); }
.btn--danger { background: rgba(226,106,106,0.16); color: #ffd3d3; border-color: rgba(226,106,106,0.4); }
.btn:hover { transform: translateY(-1px); }
.btn:active { transform: translateY(0); }
.btn:disabled { opacity: .5; cursor: not-allowed; transform: none; }
.btn.is-loading { opacity: .7; cursor: wait; }
.btn__label { white-space: nowrap; }
.btn__icon { display: inline-flex; }

/* IconButton */
.icon-btn { display: inline-flex; align-items: center; justify-content: center; border-radius: var(--radius-lg); cursor: pointer; transition: background var(--motion-base) var(--motion-ease), border-color var(--motion-base) var(--motion-ease); border: 1px solid transparent; color: var(--text); }
.icon-btn--sm { width: var(--control-h-sm); height: var(--control-h-sm); }
.icon-btn--md { width: var(--control-h-md); height: var(--control-h-md); }
.icon-btn--lg { width: var(--control-h-lg); height: var(--control-h-lg); }
.icon-btn--ghost { background: rgba(255,255,255,0.03); }
.icon-btn--ghost:hover { background: rgba(255,255,255,0.08); }
.icon-btn--solid { background: var(--surface-4); border-color: var(--stroke); }
.icon-btn--danger { color: #ffb1b1; }
.icon-btn--danger:hover { background: rgba(226,106,106,0.18); }
.icon-btn.is-active { background: rgba(245,165,36,0.14); color: var(--accent); border-color: rgba(245,165,36,0.4); }
```

**Acceptance check:** componentes existen, render con storybook-like ad-hoc en `testing/manual/UIPlayground.tsx` (opcional pero recomendado). Tipos exportan correctamente.

---

### Ticket S3-T2 — `<Tabs>` con ARIA correcto

`src/shared/ui/Tabs.tsx`:

```tsx
import { useId, useRef, type ReactNode, type KeyboardEvent } from 'react';

type Tab<T extends string> = { id: T; label: string; icon?: ReactNode; disabled?: boolean };

export function Tabs<T extends string>({
  tabs, activeId, onChange, ariaLabel,
}: {
  tabs: Tab<T>[];
  activeId: T;
  onChange: (id: T) => void;
  ariaLabel: string;
}): JSX.Element {
  const baseId = useId();
  const refs = useRef<Record<string, HTMLButtonElement | null>>({});

  function onKeyDown(e: KeyboardEvent<HTMLDivElement>, idx: number): void {
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight' && e.key !== 'Home' && e.key !== 'End') return;
    e.preventDefault();
    const list = tabs.filter((t) => !t.disabled);
    const cur = list.findIndex((t) => t.id === tabs[idx].id);
    let nextIdx = cur;
    if (e.key === 'ArrowLeft') nextIdx = (cur - 1 + list.length) % list.length;
    if (e.key === 'ArrowRight') nextIdx = (cur + 1) % list.length;
    if (e.key === 'Home') nextIdx = 0;
    if (e.key === 'End') nextIdx = list.length - 1;
    const next = list[nextIdx];
    onChange(next.id);
    refs.current[next.id]?.focus();
  }

  return (
    <div className="tabs" role="tablist" aria-label={ariaLabel}>
      {tabs.map((tab, i) => {
        const isActive = tab.id === activeId;
        const tabId = `${baseId}-tab-${tab.id}`;
        const panelId = `${baseId}-panel-${tab.id}`;
        return (
          <button
            key={tab.id}
            ref={(el) => { refs.current[tab.id] = el; }}
            type="button"
            role="tab"
            id={tabId}
            aria-controls={panelId}
            aria-selected={isActive}
            tabIndex={isActive ? 0 : -1}
            disabled={tab.disabled}
            className={`tabs__tab ${isActive ? 'is-active' : ''}`.trim()}
            onClick={() => onChange(tab.id)}
            onKeyDown={(e) => onKeyDown(e, i)}
          >
            {tab.icon ? <span className="tabs__icon">{tab.icon}</span> : null}
            <span className="tabs__label">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}
```

CSS:

```css
.tabs { display: grid; grid-auto-flow: column; grid-auto-columns: 1fr; gap: var(--space-3); padding: var(--space-5) var(--space-6) 0; }
.tabs__tab { display: inline-flex; align-items: center; justify-content: center; gap: var(--space-3); min-height: var(--control-h-md); padding: 0 var(--space-5); border-radius: var(--radius-lg); background: rgba(255,255,255,0.03); color: var(--muted); border: 1px solid transparent; cursor: pointer; font-weight: 600; font-size: var(--font-size-sm); transition: background var(--motion-base) var(--motion-ease), color var(--motion-base) var(--motion-ease), border-color var(--motion-base) var(--motion-ease); }
.tabs__tab:hover { background: rgba(255,255,255,0.06); color: var(--text); }
.tabs__tab.is-active { background: rgba(245,165,36,0.10); color: var(--accent); border-color: rgba(245,165,36,0.32); }
.tabs__tab:disabled { opacity: 0.4; cursor: not-allowed; }
.tabs__tab:focus-visible { box-shadow: var(--shadow-focus-keyboard); outline: none; }
```

**Migración requerida:**
- `DocumentInspectorPanel`: reemplazar `<div className="inspector-tabs"><button …></button>…</div>` por `<Tabs tabs={[…]} activeId={tab} onChange={setTab} ariaLabel="Document inspector tabs" />`.
- `WidgetInspectorPanel`: idem.
- `StoryFlowSection` chip-row: NO migrar a Tabs porque son filtros, no tabs. Es para SegmentedControl (S3-T4).

**Acceptance check:**
- `grep -rE 'role="tab"' src/` ≥ 2.
- Navegación teclado: `ArrowLeft/Right/Home/End` funciona en cada `<Tabs>`.
- Visualmente activo no es verde "primary" (ya no compite con Save).

---

### Ticket S3-T3 — `<Field>`, `<NumberField>`, `<SelectField>`

```tsx
// src/shared/ui/Field.tsx
import type { ReactNode } from 'react';

export function Field({ label, hint, htmlFor, children, error, inline = false }: {
  label: string; hint?: string; htmlFor?: string; children: ReactNode; error?: string; inline?: boolean;
}): JSX.Element {
  return (
    <div className={`field ${inline ? 'field--inline' : ''}`}>
      <label className="field__label" htmlFor={htmlFor}>{label}</label>
      <div className="field__control">{children}</div>
      {error ? <small className="field__error">{error}</small> : hint ? <small className="field__hint">{hint}</small> : null}
    </div>
  );
}
```

`<NumberField>` debe wrap input type=number con steppers nativos opcionalmente desactivables y soporte de drag-to-scrub (Cmd/Ctrl + arrastrar horizontal sobre el label, patrón Figma) — en una segunda iteración. **Por ahora**, simplemente forwarding a `<input type="number">` con clase `.field__input--number`.

**Migración:** todos los `<label>X</label><input … />` en inspector → `<Field label="X"><input … /></Field>`.

---

### Ticket S3-T4 — `<SegmentedControl>` para los chip-rows

Hoy `chip-row` se usa en widget library categories y en story-flow. Componente:

```tsx
export function SegmentedControl<T extends string>({
  options, value, onChange, ariaLabel,
}: {
  options: Array<{ id: T; label: string; count?: number }>;
  value: T; onChange: (v: T) => void; ariaLabel: string;
}): JSX.Element { /* … */ }
```

Migrar `WidgetLibrarySection`'s `chip-row`.

---

### Ticket S3-T5 — `<Toolbar>` y `<ToolbarGroup>`

Para floating toolbar y stage toolbars. Maneja drag handle, dividers verticales, alineación.

```tsx
// signature
<Toolbar position={{x,y}} onDragHandlePointerDown={…} draggable>
  <ToolbarGroup>
    <IconButton … />
  </ToolbarGroup>
  <ToolbarDivider />
  <ToolbarGroup>…</ToolbarGroup>
</Toolbar>
```

Migrar `StageFloatingToolbar`, `StageSelectionToolbar`, `TimelineHeader` controls, `TopBarActions`.

---

### Ticket S3-T6 — `<Tile>` (la utility de "card-de-panel")

Reemplazo del patrón inline `style={{ border: '1px solid rgba(255,255,255,.08)', borderRadius: 12, padding: 10 }}` repetido 6+ veces.

```tsx
export function Tile({ tone = 'neutral', children, className = '' }: {
  tone?: 'neutral' | 'success' | 'warning' | 'danger';
  children: ReactNode;
  className?: string;
}): JSX.Element {
  return <div className={`tile tile--${tone} ${className}`.trim()}>{children}</div>;
}
```

CSS con tokens. Reemplazar TODOS los inline-style de borde+radius+padding por `<Tile>`.

---

### Ticket S3-T7 — Lint contra inline-styles peligrosos

Añadir ESLint rule custom (o `react/forbid-component-props`) que **avise** (no bloquee) sobre el uso de `style={{ … }}` con propiedades `padding`, `margin`, `border`, `borderRadius`, `background`, `color` (todo lo que tenga token). Permitir `transform`, `left`, `top`, `width`, `height` (runtime drag/resize).

**Acceptance check del sprint 3:** `grep -rE "style=\{\{" src/inspector src/app/shell src/timeline | wc -l` baja de 93 a < 25 (queda solo lo runtime: drag positions, transforms calculados, color picker en vivo).

---

## SPRINT 4 — Shell con CSS variables y persistencia

### Ticket S4-T1 — Reemplazar dimensiones inline por CSS vars

**Archivo:** `src/app/shell/StudioShell.tsx`.

Reemplazar:

```tsx
// ANTES
<div
  className="studio-shell"
  style={{
    gridTemplateColumns: `${leftRailHidden ? '0px' : `${leftRailWidth}px`} minmax(0, 1fr) ${rightInspectorHidden ? '0px' : '328px'}`,
    gridTemplateRows: `64px minmax(0, 1fr) ${timelineHidden ? '0px' : `${timelineHeight}px`}`,
  }}
>
```

por:

```tsx
// DESPUÉS
<div
  className={`studio-shell ${leftRailHidden ? 'is-left-collapsed' : ''} ${rightInspectorHidden ? 'is-right-collapsed' : ''} ${timelineHidden ? 'is-bottom-collapsed' : ''}`.trim()}
  style={{
    '--shell-left-w': leftRailHidden ? '0px' : `${leftRailWidth}px`,
    '--shell-right-w': rightInspectorHidden ? '0px' : `${rightInspectorWidth}px`,
    '--shell-bottom-h': timelineHidden ? '0px' : `${timelineHeight}px`,
  } as React.CSSProperties}
>
```

Y en `shell.css`:

```css
.studio-shell {
  display: grid;
  grid-template-columns: var(--shell-left-w) minmax(0, 1fr) var(--shell-right-w);
  grid-template-rows: var(--shell-top-h) minmax(0, 1fr) var(--shell-bottom-h);
  grid-template-areas:
    "top top top"
    "left workspace inspector"
    "left timeline inspector";
  height: 100vh;
  transition: grid-template-columns var(--motion-base) var(--motion-ease),
              grid-template-rows var(--motion-base) var(--motion-ease);
}
```

### Ticket S4-T2 — Inspector resizable

Replicar el patrón del LeftRail. Añadir `<div className="right-inspector-resize-handle" />` y `useState rightInspectorWidth` con clamp 280–520, persistido.

### Ticket S4-T3 — Persistencia de layout

Crear `src/app/shell/use-shell-layout.ts`:

```ts
import { useEffect, useState } from 'react';

const STORAGE_KEY = 'smx.studio.shell.layout.v1';

type ShellLayout = {
  leftRailWidth: number;
  rightInspectorWidth: number;
  timelineHeight: number;
  leftRailHidden: boolean;
  rightInspectorHidden: boolean;
  timelineHidden: boolean;
};

const DEFAULT: ShellLayout = {
  leftRailWidth: 288,
  rightInspectorWidth: 328,
  timelineHeight: 260,
  leftRailHidden: false,
  rightInspectorHidden: false,
  timelineHidden: false,
};

function load(): ShellLayout {
  if (typeof window === 'undefined') return DEFAULT;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT, ...parsed };
  } catch { return DEFAULT; }
}

export function useShellLayout() {
  const [layout, setLayout] = useState<ShellLayout>(load);
  useEffect(() => {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(layout)); } catch { /* ignore */ }
  }, [layout]);
  return [layout, setLayout] as const;
}
```

Reemplazar los useState scattered en `StudioShell` por este hook único.

**Acceptance check:**
- Al cerrar y abrir el editor, el layout se mantiene.
- `localStorage.getItem('smx.studio.shell.layout.v1')` muestra el JSON.
- Tests `editor-authoring-flow` no rompen (limpian localStorage en setup).

---

## SPRINT 5 — Document Inspector contract-driven

### Ticket S5-T1 — Migrar `DocumentInspectorTab` a registry

Crear `src/inspector/document-inspector-registry.ts`:

```ts
import type { ComponentType } from 'react';
import type { StudioState } from '../domain/document/types';

export type DocumentInspectorTabId = string; // antes era enum cerrado

export type DocumentInspectorPanelKey = string;

export type DocumentInspectorTabSpec = {
  id: DocumentInspectorTabId;
  label: string;
  panels: DocumentInspectorPanelKey[];
  /* opcional: tab solo visible bajo cierta condición */
  visible?: (state: StudioState) => boolean;
};

export type DocumentInspectorPanelSpec = {
  key: DocumentInspectorPanelKey;
  title: string;
  subtitle?: string;
  defaultOpen?: boolean;
  Component: ComponentType<{}>;
};

const tabs: DocumentInspectorTabSpec[] = [];
const panels = new Map<DocumentInspectorPanelKey, DocumentInspectorPanelSpec>();

export function registerDocumentInspectorTab(spec: DocumentInspectorTabSpec): void {
  if (tabs.some((t) => t.id === spec.id)) return;
  tabs.push(spec);
}
export function registerDocumentInspectorPanel(spec: DocumentInspectorPanelSpec): void {
  panels.set(spec.key, spec);
}
export function getDocumentInspectorTabs(state: StudioState): DocumentInspectorTabSpec[] {
  return tabs.filter((t) => (t.visible ? t.visible(state) : true));
}
export function getDocumentInspectorPanel(key: DocumentInspectorPanelKey): DocumentInspectorPanelSpec | undefined {
  return panels.get(key);
}
```

Crear `src/inspector/register-document-inspector.ts` (llamado desde `register-builtins.ts`):

```ts
import { registerDocumentInspectorPanel, registerDocumentInspectorTab } from './document-inspector-registry';
import { ScenesSection } from './sections/document/ScenesSection';
import { CanvasSection } from './sections/document/CanvasSection';
import { RuntimeSection } from './sections/document/RuntimeSection';
import { FeedCatalogSection } from './sections/document/FeedCatalogSection';
import { RemoteJsonImportSection } from './sections/document/RemoteJsonImportSection';
import { DiagnosticsSection } from './sections/document/DiagnosticsSection';
import { VideoAnalyticsSection } from './sections/document/VideoAnalyticsSection';
import { CommentsSection } from './sections/document/CommentsSection';
import { ApprovalsSection } from './sections/document/ApprovalsSection';
import { ShareHandoffSection } from './sections/document/ShareHandoffSection';
import { channelSupportsFeedCatalog } from './sections/document/channel-capabilities';

export function registerDocumentInspectorBuiltins(): void {
  // panels
  registerDocumentInspectorPanel({ key: 'scenes', title: 'Scenes', subtitle: 'Scene list and navigation', defaultOpen: true, Component: ScenesSection });
  registerDocumentInspectorPanel({ key: 'canvas-runtime', title: 'Canvas & runtime', subtitle: 'Stage size, background and playback defaults', Component: () => <><CanvasSection /><RuntimeSection /></> });
  registerDocumentInspectorPanel({ key: 'feed-catalog', title: 'Feed catalog', subtitle: 'Dynamic data sources and records', defaultOpen: true, Component: FeedCatalogSection });
  registerDocumentInspectorPanel({ key: 'imports-diagnostics', title: 'Imports & diagnostics', subtitle: 'Remote JSON, parsing and readiness review', Component: () => <><h3>Remote JSON import</h3><RemoteJsonImportSection /><h3>Diagnostics</h3><DiagnosticsSection /><h3>Video analytics</h3><VideoAnalyticsSection /></> });
  registerDocumentInspectorPanel({ key: 'comments', title: 'Comments', subtitle: 'Feedback threads on this document', defaultOpen: true, Component: CommentsSection });
  registerDocumentInspectorPanel({ key: 'approvals-handoff', title: 'Approvals & handoff', subtitle: 'Review state, sign-off and share links', Component: () => <><h3>Approvals</h3><ApprovalsSection /><h3>Share & handoff</h3><ShareHandoffSection /></> });

  // tabs
  registerDocumentInspectorTab({ id: 'overview', label: 'Overview', panels: ['scenes', 'canvas-runtime'] });
  registerDocumentInspectorTab({ id: 'data', label: 'Data', panels: ['feed-catalog', 'imports-diagnostics'], visible: (s) => channelSupportsFeedCatalog(s.document.metadata.release.targetChannel) });
  registerDocumentInspectorTab({ id: 'collab', label: 'Collab', panels: ['comments', 'approvals-handoff'] });
}
```

Refactorizar `DocumentInspectorPanel.tsx` a:

```tsx
export function DocumentInspectorPanel(): JSX.Element {
  const state = useStudioStore((s) => s);
  const tabs = useMemo(() => getDocumentInspectorTabs(state), [state]);
  const [activeId, setActiveId] = useState(tabs[0]?.id ?? 'overview');
  const activeTab = tabs.find((t) => t.id === activeId) ?? tabs[0];

  return (
    <>
      <Tabs tabs={tabs.map((t) => ({ id: t.id, label: t.label }))} activeId={activeId} onChange={setActiveId} ariaLabel="Document inspector" />
      {activeTab?.panels.map((key, i) => {
        const panel = getDocumentInspectorPanel(key);
        if (!panel) return null;
        const Comp = panel.Component;
        return (
          <details key={key} className="inspector-accordion" open={panel.defaultOpen ?? i === 0}>
            <summary><span>{panel.title}</span><small>{panel.subtitle}</small></summary>
            <div className="inspector-accordion-body"><Comp /></div>
          </details>
        );
      })}
    </>
  );
}
```

**Bonus opcional para el sprint:** auto-discovery vía `import.meta.glob('./inspector/sections/document/*.panel.ts')` igual que widgets, para no requerir registro manual.

**Acceptance check:**
- `DocumentInspectorTab` tipo string libre.
- Añadir un panel demo (ej.: `compliance`) con 5 líneas no toca `DocumentInspectorPanel.tsx`.
- Tests `editor-authoring-flow` pasan.

---

## SPRINT 6 — Capability flags en WidgetDefinition

### Ticket S6-T1 — Extender contrato

Editar `src/widgets/registry/widget-definition.ts`:

```ts
export type WidgetCapabilities = {
  acceptsImageAsset?: boolean;
  acceptsVideoAsset?: boolean;
  acceptsAssetSwap?: boolean;
  hasFill?: boolean;
  hasAccentColor?: boolean;
  isMedia?: boolean;
  isInteractive?: boolean;
  exposesActions?: boolean;
};

export type WidgetDefinition = {
  // … existentes
  capabilities?: WidgetCapabilities;
};

export function getCapability<K extends keyof WidgetCapabilities>(
  def: WidgetDefinition,
  key: K
): WidgetCapabilities[K] {
  return def.capabilities?.[key];
}
```

### Ticket S6-T2 — Backfill capabilities en los 31 definitions existentes

Tabla guía (ejemplos clave):

| type | acceptsImageAsset | acceptsVideoAsset | acceptsAssetSwap | hasFill | isMedia |
|---|---|---|---|---|---|
| image | ✅ |  | ✅ | ✅ | ✅ |
| hero-image | ✅ |  | ✅ | ✅ | ✅ |
| video-hero |  | ✅ | ✅ | ✅ | ✅ |
| interactive-video |  | ✅ | ✅ | ✅ | ✅ |
| image-carousel | ✅ |  | ✅ | ✅ | ✅ |
| interactive-gallery | ✅ |  | ✅ | ✅ | ✅ |
| shoppable-sidebar | ✅ |  | ✅ | ✅ | ✅ |
| text |  |  |  | ✅ |  |
| cta |  |  |  | ✅ |  |
| dynamic-map |  |  |  |  |  |
| countdown |  |  |  | ✅ |  |
| ... | ... | ... | ... | ... | ... |

Codex revisa cada `*.definition.ts` y agrega el bloque correcto.

### Ticket S6-T3 — Reemplazar whitelists en componentes

**`Stage.tsx` (`openAssetPicker`):**
```diff
- if (widget.type !== 'image' && widget.type !== 'hero-image' && … ) return;
+ const def = getWidgetDefinition(widget.type);
+ if (!def?.capabilities?.acceptsAssetSwap) return;
```

**`StageSelectionToolbar.tsx` (`isMediaWidget`):**
```diff
- function isMediaWidget(widget: WidgetNode): boolean {
-   return widget.type === 'image' || …;
- }
+ function isMediaWidget(widget: WidgetNode): boolean {
+   return Boolean(getWidgetDefinition(widget.type)?.capabilities?.isMedia);
+ }
```

**`FillSection.tsx`:**
```diff
- {['image', 'hero-image', 'video-hero'].includes(widget.type) ? (…) : null}
+ {definition?.capabilities?.acceptsAssetSwap ? (…) : null}
```

Acceptance check: `grep -rE "widget\.type === 'image'" src/inspector src/canvas src/app | wc -l` baja de N a 0.

---

## SPRINT 7 — Widget Library con thumbnails

### Ticket S7-T1 — Campo opcional `thumbnail` en `WidgetDefinition`

```ts
export type WidgetDefinition = {
  // …
  thumbnail?: string | (() => JSX.Element); // URL, dataURI o componente SVG
};
```

### Ticket S7-T2 — Renderer del card

`WidgetLibrarySection` usa una nueva tarjeta:

```tsx
<div className="widget-library-grid">
  {filteredWidgets.map((widget) => {
    const def = getWidgetDefinition(widget.type);
    const Thumb = typeof def?.thumbnail === 'function' ? def.thumbnail : null;
    return (
      <button
        key={widget.type}
        type="button"
        className={`widget-library-card ${draggingWidgetType === widget.type ? 'is-dragging' : ''}`.trim()}
        draggable
        onClick={…}
        onKeyDown={…}
        onDragStart={…}
        onDragEnd={…}
      >
        <div className="widget-library-card__thumb">
          {Thumb ? <Thumb /> : typeof def?.thumbnail === 'string' ? <img src={def.thumbnail} alt="" /> : <PlaceholderThumb category={widget.category} />}
        </div>
        <div className="widget-library-card__meta">
          <span className="widget-library-card__label">{widget.label}</span>
          <span className="widget-library-card__type">{widget.type}</span>
        </div>
      </button>
    );
  })}
</div>
```

CSS grid 2 columnas, aspect-ratio del thumbnail 16/10.

### Ticket S7-T3 — `<PlaceholderThumb>` procedural

SVG generado por `category` ('content' | 'media' | 'interactive' | 'layout') con paleta tokenizada. Sirve mientras no haya thumbnail real.

### Ticket S7-T4 — Backfill thumbnails de los 5–10 módulos top usados

Codex prioriza: `image`, `hero-image`, `text`, `cta`, `video-hero`, `image-carousel`, `instagram-story`, `meta-carousel`, `teads-layout1`, `teads-layout2`, `dynamic-map`. SVG inline propios o data-URIs.

---

## SPRINT 8 — Edit-mode wireframe rendering

### Ticket S8-T1 — Hook `renderWireframe` opcional

```ts
export type WidgetDefinition = {
  // …
  renderWireframe?: (node: WidgetNode, ctx: RenderContext) => JSX.Element;
};
```

Default helper en `widget-registry.ts`:

```ts
export function defaultWireframe(node: WidgetNode, def: WidgetDefinition): JSX.Element {
  return (
    <div className="widget-wireframe">
      <span className="widget-wireframe__label">{def.label}</span>
      <span className="widget-wireframe__dims">{Math.round(node.frame.width)}×{Math.round(node.frame.height)}</span>
    </div>
  );
}
```

### Ticket S8-T2 — Stage usa wireframe en edit-mode no seleccionado

`StageWidget.tsx` lógica:
```ts
const useWireframe = !previewMode && !selected && !active && !hovered && uiActions.editModeWireframe;
const content = useWireframe
  ? (def.renderWireframe ? def.renderWireframe(node, ctx) : defaultWireframe(node, def))
  : def.renderStage(node, ctx);
```

### Ticket S8-T3 — Toggle UI

Botón `W` en `StageFloatingToolbar` y atajo `W` para alternar `editModeWireframe` en `state.ui.editModeWireframe`. Persistir en localStorage (sprint 4).

### Ticket S8-T4 — CSS

```css
.widget-wireframe { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; gap: var(--space-2); padding: var(--space-3); border: 1px dashed rgba(255,255,255,0.32); border-radius: var(--radius-md); background: rgba(255,255,255,0.02); color: var(--muted); font-size: var(--font-size-xs); pointer-events: none; user-select: none; }
.widget-wireframe__label { font-weight: 600; color: var(--text); text-transform: uppercase; letter-spacing: 0.06em; }
.widget-wireframe__dims { opacity: 0.7; }
```

**Acceptance check:** Toggle visible, estado persiste, en wireframe no se cargan videos/mapas (verificar con red devtools).

---

## SPRINT 9 — Story Flow visual canvas

### Ticket S9-T1 — Estructura del componente

Crear `src/app/shell/left-rail/StoryFlowCanvas.tsx` lazy-loaded.

API mínima (sin librería externa):
- Render escenas como nodos absolute-positioned con coords guardadas en `scene.flow.canvas = { x, y }`.
- Edges como `<svg>` overlay con paths bezier desde nodo origen al targetSceneId.
- Drag de nodos para reposicionar.
- Doble clic en escena → `selectScene(id)`.

Si Codex prefiere librería: **ReactFlow** vale, pero pesará ~80KB gzip — discutir antes de meterla en deps. Default: implementación propia minimal (~200 LoC).

### Ticket S9-T2 — Toggle vista lista ↔ canvas

`StoryFlowSection` muestra un `<SegmentedControl>` con `['list','canvas']`. Estado en localStorage.

---

## SPRINT 10 — Layers panel decision

**Decisión recomendada:** convertir Layers en outline jerárquico con árbol de scenes → widgets → grupos.

### Ticket S10-T1 — `<LayerOutline>`

Componente que muestra:
- Scene activa
- Lista de widgets ordenada por z-index
- Grupos colapsables
- Iconos: visibility, lock, drag handle
- Multi-select con shift/cmd
- Drag-to-reorder (HTML5 dnd)
- Click sobre layer → `selectWidget(id)`

Reemplaza `LayersSection.tsx`. La timeline mantiene su track header pero el outline del left rail se vuelve la fuente verdadera de jerarquía.

---

## SPRINT 11 — Polish

### S11-T1 — Reorganizar TopBar en 3 zonas
- Izquierda: back + project name + dirty dot
- Centro: scene switcher pill + canvas size pill + breadcrumb sutil
- Derecha: Preview, Export, Share, Publish, Save, status

### S11-T2 — `<Tooltip>` accesible
Reemplazar todos los `title=""` por `<Tooltip content="…">` en TopBar/Stage toolbars/IconButton (opcional integración en `<IconButton>` mismo).

### S11-T3 — `<Toast>` system
Hook `useToast()` + provider en `App.tsx`. Migrar feedback de save/export/publish/share.

### S11-T4 — Limpiar magic numbers de `Stage.clampToolbarPosition`
Medir el toolbar con ResizeObserver en lugar de hardcodear 520/68/176.

### S11-T5 — Mover `BACKGROUND_SWATCHES` a config
`src/domain/document/canvas-presets.ts` con export `STAGE_BACKGROUND_SWATCHES`.

### S11-T6 — `PositionSection` añadir Opacity, Rotation, Lock-aspect
Tres campos extra en el grid 2x2 → 3x2.

### S11-T7 — Decidir idioma único en LoginScreen
Inglés es el default sano. ES queda solo si se introduce i18n real en el futuro.

---

## Anexo A — Checks pre-merge para CADA PR

```bash
pnpm typecheck:web   # 0 errores
pnpm test:web        # 166/166 (o más)
pnpm build:web       # OK
pnpm lint:css        # 0 violaciones (a partir de S1-T3)
pnpm lint            # 0 errores ESLint
```

Visual:
- Manual smoke en `#/editor` con un proyecto Bocadeli o Lay's existente: el editor abre, los widgets se ven igual, la export entrega un ZIP idéntico al pre-PR (diff binario tolerable solo en assets generados como thumbnails nuevos).

## Anexo B — Convenciones para Codex

- **Commits atomicos por ticket.** `feat(studio/ui): add Tabs primitive`, `refactor(studio/css): split layout into shell/topbar/etc`, `chore(studio/lint): add stylelint guard for tokens`.
- **Branch naming:** `studio-ux/sprint-N-ticket-id`.
- **PR template:** debe incluir checkbox del acceptance check del ticket y screenshots before/after del área tocada.
- **NUNCA** introducir dependencias UI runtime sin discutir (estimación de bundle size + treeshakeability).

## Anexo C — Lo que NO se hace en este plan

- No tocar exporters ni runtime de export. Es zona protegida.
- No migrar a Tailwind. Decisión explícita.
- No tocar el dominio (`src/domain/document/*`) salvo `WidgetDefinition` extensiones additivas.
- No introducir Storybook todavía (pero el `testing/manual/UIPlayground.tsx` opcional cumple la función mínima).
- No migrar hash routing a React Router en este plan.
- No tocar el sistema de autosave ni los repos.

## Anexo D — Métricas objetivo al final del SPRINT 11

| Métrica | Hoy | Objetivo |
|---|---|---|
| `wc -l src/shared/styles/*.css` (max) | 4 005 | < 800 |
| Selectores duplicados | 100+ | 0 |
| Colores hex/rgba sueltos en CSS | 301+ | 0 (todo via tokens) |
| Glyphs Unicode como iconos | ~30 | 0 |
| Componentes en `src/shared/ui/` | 1 | ≥ 10 |
| `style={{...}}` inline en JSX | 93 | < 25 |
| Roles ARIA tabs | 0 | ≥ 4 (document, widget, segmented, story) |
| Z-index literals fuera de tokens | 18 | 0 |
| `!important` en CSS | 4 | 0 |
| Whitelist de `widget.type` en componentes UI | 6+ | 0 (capabilities) |
| Layout shell persiste entre sesiones | No | Sí |
| Inspector resizable | No | Sí |
| Widget library con thumbnails | No | Sí |
| Edit-mode wireframe real | No | Sí |
| Story flow canvas visual | No | Sí |

---

**Fin del plan. Codex, leer S1 → S11 en orden, ejecutar un sprint a la vez, validar acceptance checks, NO mezclar sprints en un mismo PR.**
