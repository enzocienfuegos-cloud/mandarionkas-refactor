# Studio Frontend Audit

## Scope

Este documento cubre el frontend de Studio ubicado en:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio`

El paquete corresponde a:

- `@smx/studio`

Inventario base del scope auditado:

- `446` archivos dentro de `apps/studio`, excluyendo `node_modules` y `dist`
- app React + TypeScript + Vite
- editor visual con shell propia, store central custom, sistema de widgets, exportación y flujos de persistencia

## Qué Es Studio

Studio es el editor visual/interactive builder del ecosistema SMX. Su frontend combina:

- una capa de plataforma para login, sesión, selección de cliente y workspace hub
- una capa de editor para authoring de piezas
- un canvas con stage, selección, transformaciones y drag/drop
- un inspector lateral derecho para documento, widgets y configuraciones
- una timeline inferior para secuencias y keyframes
- un sistema de exportación/publicación hacia ad server
- repositorios locales/API para proyectos, documentos, assets y versiones

## Stack Del Front

### Base tecnológica

- `React 18`
- `TypeScript`
- `Vite 5`
- `Vitest`
- `use-sync-external-store`

### Dependencias funcionales relevantes

- `leaflet`
  - mapas y módulos geográficos
- `video.js`
  - runtime/video widgets
- `xlsx`
  - ingestión o soporte de flujos con hojas de cálculo
- `@aws-sdk/client-s3`
  - operaciones con assets/storage
- `@smx/contracts`
  - contratos compartidos con backend/plataforma
- `@smx/vast`
  - export/runtime vinculado a VAST

### Build y runtime

Archivo:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/package.json`

Scripts:

- `dev`: Vite en puerto `5174`
- `build`: `tsc --noEmit` + `vite build`
- `test`: `vitest run`

Vite:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/vite.config.ts`

Notas de arquitectura:

- alias locales para `@smx/contracts` y `@smx/vast`
- proxy dev de `/v1` hacia `http://localhost:4000`
- chunking manual para `react`, `leaflet`, `video.js` y `xlsx`
- base path configurable con `VITE_PUBLIC_BASE_PATH`

## Bootstrap Del App

### Entry point

Archivos:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/main.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/App.tsx`

Secuencia:

1. `registerBuiltins()` registra widgets/plugins built-in.
2. `configureRuntimeDependencies()` conecta servicios de plataforma y resolver de repositorios.
3. React monta `App`.
4. `App` carga:
   - `AutosaveGate`
   - `FontAssetRuntime`
   - `PlatformShell`

Esto muestra que Studio no entra directo al editor. Primero pasa por una shell de plataforma/sesión.

## Flujo De Navegación Del Front

Archivo central:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/platform/PlatformShell.tsx`

### Rutas

Studio usa routing por `hash`, no React Router.

Estados principales:

- `#/hub`
  - shell de agencia
- `#/hub/client/:clientId`
  - shell de workspace de cliente
- `#/editor`
  - editor Studio

### Flujo principal

1. `restoreSession()` intenta restaurar la sesión.
2. Si no hay sesión:
   - muestra `LoginScreen`
3. Si hay sesión:
   - `AgencyShell`
   - `ClientWorkspaceShell`
   - `StudioShell`

### Consecuencia para auditoría UX

El producto no es una sola pantalla. Tiene tres capas front distintas:

- login/auth
- command center / workspace hub
- editor visual

Cada una merece auditoría separada.

## Flujo De Auth y Plataforma

Archivos principales:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/platform/auth-service.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/platform/api.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/platform/runtime.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/platform/state.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/platform/store.ts`

Responsabilidades:

- restaurar sesión
- login/logout
- sincronizar usuario actual
- cliente activo
- permisos y rol
- mantener snapshot de plataforma consumido por la UI

Hallazgo importante:

- Studio mezcla concerns de producto con concerns de plataforma dentro del mismo frontend
- eso aumenta complejidad de onboarding y de auditoría visual/funcional

## Shell Del Editor

Archivo central:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/app/shell/StudioShell.tsx`

### Layout principal

La shell se organiza como grid con:

- top bar
- left rail
- workspace central
- right inspector
- bottom timeline

Paneles controlados por estado local:

- ancho left rail
- hidden/show left rail
- hidden/show inspector
- hidden/show timeline
- altura timeline
- modal de asset library

### Archivos relevantes

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/app/shell/TopBar.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/app/shell/LeftRail.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/app/shell/Workspace.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/inspector/RightInspector.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/timeline/BottomTimeline.tsx`

### Subáreas del shell

`topbar/`

- controles de documento
- export
- publicación
- workspace controls
- project session
- status

`left-rail/`

- asset library
- collaboration
- layers
- story flow
- widget library

## State Management

Carpeta:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/core`

Readmes clave:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/core/README.md`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/core/store/README.md`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/core/commands/README.md`

### Modelo

Studio usa store custom, no Redux/Zustand.

Piezas:

- `core/commands`
  - contrato de intenciones del usuario
- `core/history`
  - undo/redo
- `core/persistence`
  - snapshot serializable
- `core/store`
  - store central y reducers por slice

Archivos clave:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/core/store/studio-store.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/core/store/use-studio-store.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/hooks/use-studio-actions.ts`

### Implicación para auditoría

El front no está pensado como una simple app CRUD. Está más cerca de un producto tipo editor/Figma-lite:

- comandos explícitos
- reducers por slice
- historial
- selectors derivados
- fuerte separación entre intención, estado y render

## Canvas / Stage

Carpeta:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/canvas/stage`

Responsabilidades:

- render del canvas
- viewport
- geometría
- marquee selection
- drag/drop de assets y widgets
- transform controls
- clipboard de widgets

Archivos clave:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/canvas/stage/Stage.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/canvas/stage/use-stage-controller.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/canvas/stage/controllers/use-stage-selection-controller.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/canvas/stage/controllers/use-stage-transform-controller.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/canvas/stage/components/StageSurface.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/canvas/stage/components/StageWidget.tsx`

Flujo del área central:

1. `Workspace` monta el stage
2. el stage consume snapshot/selectors del store
3. controladores convierten input del usuario en comandos
4. reducers actualizan estado
5. render vuelve a pintar widgets

## Inspector Derecho

Carpeta:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/inspector`

Paneles:

- `DocumentInspectorPanel`
- `WidgetInspectorPanel`
- `MultiSelectionInspectorPanel`

Secciones de documento:

- canvas
- scenes
- diagnostics
- export
- approvals
- comments
- release settings
- runtime
- share handoff
- story info
- video analytics

Secciones de widget:

- fill
- text
- timing
- position
- variants
- conditions
- actions
- keyframes
- utilities

Esto sugiere que la auditoría visual debe cubrir dos tipos de inspector:

- document-level controls
- widget-level controls

## Timeline

Carpeta:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/timeline`

Responsabilidades:

- ruler
- overview
- track list
- row editor
- tracks/rows por escena o widget

Archivos clave:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/timeline/BottomTimeline.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/timeline/components/TimelineRuler.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/timeline/components/TimelineTrackList.tsx`

## Widgets y Sistema De Módulos

Carpeta dominante:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/widgets`

Volumen:

- `140` archivos dentro de `widgets`
- `63` archivos en `widgets/modules`
- `31` definiciones en `widgets/modules/definitions`

Tipos observables:

- text
- image
- hero image
- shape
- badge
- cta
- group
- video
- video hero
- módulos interactivos avanzados

Módulos especiales relevantes:

- `interactive-gallery`
- `interactive-video`
- `instagram-story`
- `dynamic-map`
- `drop-zone`
- `scratch-reveal`
- `shoppable-sidebar`
- `tiktok-video`
- `weather-conditions`
- `teads-layout1`
- `teads-layout2`

Arquitectura de widgets:

- `*.definition.ts`
  - schema/configuración
- `*.renderer.tsx`
  - render visual
- `*.inspector.tsx`
  - controles de edición

Registry:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/widgets/registry/register-builtins.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/widgets/registry/widget-registry.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/widgets/registry/builtin-widget-plugins.ts`

## Persistencia y Repositorios

Carpetas:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/persistence`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/repositories`

### Autosave

Archivo:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/persistence/autosave/AutosaveGate.tsx`

Flujo:

1. observa `dirty`
2. genera firma de persistencia
3. debounce de `700ms`
4. genera snapshot
5. guarda draft autosave
6. marca `autosaved`

### Repositorios

Áreas:

- `project`
- `project-versions`
- `document`
- `asset`
- `video-analytics`

Modos:

- local
- API

Conclusión:

El frontend ya está estructurado para swap de backend/local repositories, lo cual es bueno para migraciones y pruebas, pero aumenta superficie de complejidad.

## Exportación y Publicación

Carpeta:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/export`

Responsabilidades:

- compliance
- packaging
- bundle assembly
- asset resolution
- adapters por canal
- zip/download
- runtime model

Canales/adapters visibles:

- generic html5
- GAM html5
- Google display
- MRAID
- playable
- VAST SIMID

Publicación a ad server:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/app/shell/topbar/studio-publication.ts`

Flujo:

1. prepara estado exportable
2. resuelve assets remotos
3. construye bundle
4. serializa files
5. hace `POST` a `/creative-publications/from-studio`

## Assets

Carpeta:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/assets`

Responsabilidades:

- runtime de fuentes
- contratos y tipos
- optimización de imagen/video
- pipeline de asset processing
- proveedores de storage

Proveedores observables:

- API storage provider
- demo storage provider

## Styling Del Front

Archivos centrales:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/shared/theme.css`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/shared/layout.css`

Observación importante:

- `layout.css` es una pieza crítica y probablemente muy grande/centralizada
- el layout visual del editor parece depender mucho de CSS global tradicional

Esto es un hotspot claro para auditoría porque:

- puede generar deuda visual
- puede mezclar concerns de shell, paneles, widgets y responsive
- dificulta sistematizar tokens/componentes si no se segmenta

## Testing Del Front

Carpeta:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/testing`

Cobertura estructural:

- `smoke`
- `unit`
- `architecture`
- `manual`
- `fakes`
- `fixtures`
- `helpers`

Smokes relevantes:

- `document-persistence-flow`
- `editor-authoring-flow`
- `project-workspace-flow`
- `repository-backend-swap-flow`

Arquitectura:

- hay guardrails explícitos de imports/layers

Esto es valioso para refactor visual, porque ayuda a no romper límites internos.

## Mapa De Carpetas

### Nivel alto

- `src/actions` — runtime side-effects
- `src/app` — shell del editor y bootstrap
- `src/assets` — runtime, policy y providers de assets
- `src/canvas` — stage/canvas y controladores de interacción
- `src/config` — runtime config
- `src/core` — store, history, commands, persistence core
- `src/domain` — tipos, factories, lógica documental
- `src/export` — empaquetado y adapters de export
- `src/hooks` — hooks de acciones del store
- `src/inspector` — panel derecho y secciones
- `src/integrations` — utilidades de integración
- `src/persistence` — autosave/persistencia UX
- `src/platform` — login, workspace hub, agency shell, sesión
- `src/repositories` — capa de acceso a datos local/API
- `src/shared` — CSS global y utilidades compartidas
- `src/testing` — pruebas y guardrails
- `src/timeline` — timeline inferior
- `src/widgets` — sistema de widgets del editor

### Conteo por área

- `actions`: 2
- `app`: 35
- `assets`: 13
- `canvas`: 25
- `config`: 1
- `core`: 25
- `domain`: 8
- `export`: 31
- `hooks`: 1
- `inspector`: 34
- `integrations`: 1
- `persistence`: 2
- `platform`: 29
- `repositories`: 20
- `shared`: 6
- `testing`: 49
- `timeline`: 9
- `types`: 1
- `widgets`: 140

## Flujos Front Más Importantes Para Auditar

### 1. Login y restauración de sesión

- `LoginScreen`
- `restoreSession()`
- transición a agency shell / workspace / editor

### 2. Navegación plataforma → editor

- `AgencyShell`
- `ClientWorkspaceShell`
- `StudioShell`

### 3. Authoring dentro del editor

- left rail selecciona assets/widgets/layers
- canvas renderiza y permite interacción
- inspector modifica documento/widget
- timeline ajusta secuencia y keyframes

### 4. Persistencia

- cambios marcan estado dirty
- `AutosaveGate` genera snapshot
- repositorios guardan local/API

### 5. Export / publish

- validación de readiness
- bundle generation
- adapter por canal
- publicación al ad server

## Hotspots Claros Para Mejorar El Front

### Visual system

- CSS global muy centralizado en `shared/layout.css`
- alta probabilidad de inconsistencia entre shells y paneles

### Complejidad del shell

- platform + editor viven en el mismo frontend
- la experiencia puede sentirse como varios productos dentro de uno

### Discoverability

- left rail, right inspector, timeline y topbar compiten por atención
- el editor tiene muchas superficies densas

### Escalabilidad de widgets

- el volumen de `widgets/modules` sugiere alto costo de mantenimiento
- conviene auditar consistencia entre `definition`, `renderer` e `inspector`

### Navegación

- hash routing custom
- puede limitar deep linking, trazabilidad y patrones más modernos de navegación

## Qué Incluye El Zip

El `.zip` generado para auditoría contiene `apps/studio` completo, excluyendo:

- `node_modules`
- `dist`

Incluye:

- código fuente
- tests
- configuraciones
- env files dentro del paquete
- Dockerfile

## Archivos Más Importantes Para Leer Primero

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/main.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/App.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/platform/PlatformShell.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/app/shell/StudioShell.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/core/store/studio-store.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/hooks/use-studio-actions.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/canvas/stage/Stage.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/inspector/RightInspector.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/timeline/BottomTimeline.tsx`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/app/shell/topbar/studio-publication.ts`
- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio/src/shared/layout.css`

## Inventario Completo De Archivos

El inventario exhaustivo del frontend está cubierto por el `.zip`. Para revisión rápida, la fuente auditada es:

- `/Users/enzocienfuegos/Documents/MandaRion/apps/studio`

Si quieres un segundo entregable más granular, el siguiente paso natural es generarte un `front-audit-phase-2.md` con:

- componente por componente
- deuda visual priorizada
- quick wins
- estrategia de redesign del shell
- propuesta de design system/tokens específicos para Studio
