# SMX Studio — UX/UI Senior Audit (Rich Media / AdTech)

**Auditor:** Senior UX-UI ADTech (perspectiva Celtra / Connected Stories / CreativeStudio).
**Audited:** `apps/studio` snapshot `2026-05-07` (446 archivos React + TypeScript + Vite).
**Fecha:** 2026-05-08.
**Persona:** Diseñador rich media que arma banners modulares y exporta tags (Adform / GAM / CM360 / MRAID / VAST).

> **TL;DR.** El núcleo arquitectónico (store, comandos, contrato `WidgetDefinition`, autosave, registry, export adapters) está a la altura de un editor pro. Lo que NO está a la altura es la capa de presentación: **un solo `layout.css` de 4 005 líneas con 778 selectores, 301 colores hardcoded, 18 valores de z-index sin escala, iconos como caracteres Unicode, 93 inline-styles dispersos en JSX y un único componente UI compartido (`ColorControl`)**. Eso significa que cada nuevo widget o panel hereda inconsistencia visual y riesgos de pixel-shift; bloquea el "pixel-perfect" y el "estilo aprovechado al 100%". Hay tres tipos de fix: **(A) tokens y design system primitivos** (radius, spacing, z-index, motion, surface), **(B) componentes UI compartidos** (Button, Tabs, IconButton, Field, Tile, Toolbar) que cierren la entropía CSS, **(C) consolidaciones UX** (Layers ↔ Timeline, Story Flow visual, Widget Library con thumbnails, edit-mode wireframe real). El plan de implementación está en el documento separado `STUDIO-CODEX-IMPLEMENTATION-PLAN-2026-05-08.md`.

---

## 0. Cómo leer este documento

- **Fortalezas** primero, para no tirar lo que ya funciona.
- **Hallazgos** ordenados por severidad: SEV-1 (rompe pixel-perfect / GUI / escalabilidad), SEV-2 (deuda visible), SEV-3 (mejora de calidad).
- Cada hallazgo lleva: **Qué**, **Dónde**, **Por qué importa**, **Recomendación**.
- Las **recomendaciones** se traducen 1-a-1 en tickets en el plan de Codex.

---

## 1. Fortalezas reales (no tocar)

| Pieza | Por qué es buena |
|---|---|
| `WidgetDefinition` / `widget-inspector-layout.tsx` | Contract-driven, declarativo, escalable. Cada nuevo módulo se autodescubre vía `import.meta.glob` sobre `*.definition.ts`. Esto es exactamente lo que hace bien Celtra. |
| Store custom + comandos + history + autosave | Separación nítida intención → estado → render. `AutosaveGate` con debounce 700 ms y firma de persistencia. |
| Stage controller + viewport + clipboard + drop preview | Pan/zoom, marquee, transform handles, drop preview, paste ghost. Núcleo de canvas correcto. |
| Export adapters por canal (`generic-html5`, `gam-html5`, `mraid`, `playable`, `vast-simid`, `google-display`) | Aislados, reemplazables. La capa de export es un ciudadano de primera. |
| Repos local/API swappable con guardrails de tests por capa | Permite trabajar sin backend y migrar sin quebrar. |
| `StageSelectionToolbar` con SVG icons inline | El único lugar donde sí hay un set de iconos vectoriales coherente. |

**Implicación:** la base es sólida. Toda la deuda está en la **capa visual/presentacional**, no en el modelo. Por lo tanto los fixes son acotados y reversibles.

---

## 2. Hallazgos SEV-1 (riesgo de pixel-perfect / escalabilidad / "puede romper la GUI")

### SEV-1.1 — `layout.css` es un monolito sin tokens
- **Qué.** `src/shared/layout.css` tiene 4 005 líneas, 778 selectores, **301 colores únicos hardcoded**, **185 dimensiones en px**, **12 tamaños de fuente distintos**, **11 valores de border-radius**, **18 valores de z-index sin orden**, 4 `!important`, breakpoints scattered (760, 1100, 1180, 1280px).
- **Dónde.** `src/shared/layout.css` (todo).
- **Por qué importa.** Imposible auditar cascada. Imposible garantizar pixel-perfect. Cualquier cambio puede tener efecto colateral. Selectores como `.workspace-toolbar`, `.inspector-tabs`, `.section-premium` aparecen redefinidos 5–9 veces — la última definición gana, pero quien lee la primera no entiende por qué su edición no se aplica.
- **Recomendación.**
  - (a) Promover `theme.css` a un set de tokens completo: `--space-{0..10}`, `--radius-{xs,sm,md,lg,xl,pill}`, `--font-size-{xs..xl}`, `--shadow-{1..3}`, `--motion-{fast,base,slow}`, `--z-{base,raised,sticky,popover,modal,toast,top}`, `--surface-{1..5}`.
  - (b) Partir `layout.css` por dominio: `shell.css`, `topbar.css`, `left-rail.css`, `inspector.css`, `timeline.css`, `stage.css`, `assets.css`, `platform.css`. Imports ordenados desde `shared/styles/index.css`.
  - (c) Reemplazar todos los hex/rgba sueltos por tokens. Auditar con un script que falle el build si aparece `rgba(255,255,255,0.0X)` no tokenizado.

### SEV-1.2 — Z-index sin escala
- **Qué.** Valores observados: `0, 1, 2, 3, 4, 5, 9, 10, 12, 20, 30, 40, 200, 999, 1500, 1600, 2000, 2600`. No hay convención.
- **Dónde.** Todo `layout.css`. Ej.: `selection-handle: 999`, `playhead-overlay: 1500`, `selection-outline-primary: 1600`, `stage-guide.active: 2000`, `floating modal: 2600`.
- **Por qué importa.** Es la causa #1 del riesgo "rompe la GUI": un popover, tooltip o nuevo overlay tiene que adivinar contra qué z-index pelear. Cuando se sume Vector mask preview o Asset hover preview o un dropdown menu, alguien va a poner `z-index: 9999` y romper otra cosa.
- **Recomendación.** Escala fija en tokens y prohibición de números literales:
  ```
  --z-base: 0;        /* canvas, widgets */
  --z-raised: 100;    /* selección, handles, rulers */
  --z-sticky: 200;    /* overlays sticky del stage */
  --z-floating: 400;  /* floating toolbars */
  --z-popover: 800;   /* dropdowns, menus, tooltips */
  --z-modal: 1200;    /* asset library, dialogs */
  --z-toast: 1600;    /* notifications */
  --z-top: 2000;      /* drag ghost, debug overlays */
  ```

### SEV-1.3 — No existe sistema de iconos
- **Qué.** ~30+ usos de glyphs Unicode/emoji como iconos: `▦ ☰ ◫ ⇄ ⚙ ‹ › ⌃ ⌄ ✕ ✓ ⏮ ⏸ ▶ ⏭ ← → ⋮⋮ ▣ ⧉ 🗑 ↕ ⇄ ↳ ▾ ▸ ∅ ＋`. Renderizan diferente por SO/fuente. Inter no contiene esos glyphs nativos, así que caen al fallback del SO.
- **Dónde.** `LeftTabBar.tsx`, `LeftRail.tsx`, `StudioShell.tsx` (collapsed tabs), `TopBar*.tsx`, `StageFloatingToolbar.tsx`, `TimelineHeader.tsx`, `AssetLibraryModal.tsx`, `StoryFlowSection.tsx`. Solo `StageSelectionToolbar.tsx` usa SVG inline propio.
- **Por qué importa.** Pixel-perfect imposible. Tamaños no controlados, alineación vertical irregular, peso visual inconsistente. Un editor pro necesita un set único.
- **Recomendación.** Adoptar un set: opción 1 — **lucide-react** (ya está validado en otros sub-proyectos del ecosistema, ligero, treeshakeable, MIT). Opción 2 — set propio en `src/shared/ui/icons/*.tsx` con SVG 24×24 viewBox normalizado, `currentColor`. **Migrar todo en una pasada y prohibir glyphs vía lint rule** (regex en `pre-commit`).

### SEV-1.4 — No existe sistema de componentes UI compartidos
- **Qué.** `src/shared/ui/` contiene **un único componente** (`ColorControl`). Todo lo demás se construye con `<button className="ghost compact-action">…</button>`, `<input>` crudo, `<details>` para acordeones, `<select>` nativo. No hay `<Button>`, `<IconButton>`, `<Tabs>`, `<Tooltip>`, `<Popover>`, `<Menu>`, `<Field>`, `<NumberField>`, `<Tile>`, `<Toolbar>`, `<Toggle>`, `<SegmentedControl>`, `<Slider>`, `<Stepper>`, `<Dialog>`.
- **Dónde.** Todo el front.
- **Por qué importa.** Cada lugar reinventa, cada lugar tiene su propio inline-style, cada feature trae deuda. Es la raíz de SEV-1.1 y SEV-1.6. No hay forma de garantizar pixel-perfect sin componentes.
- **Recomendación.** Crear `src/shared/ui/` con primitivos atómicos. **No** introducir Radix/HeadlessUI todavía (sumaría runtime y re-trabajo de tokens); empezar con primitivos propios sobre el actual theme.css. Si un día se quiere Radix, los wrappers ya están listos para envolverlo.

### SEV-1.5 — Selectores duplicados en `layout.css`
- **Qué.** Selectores definidos múltiples veces: `.workspace-toolbar` ×9, `.inspector-tabs` ×4, `.section-premium` ×9, `.timeline-row` ×22, `.stage-widget` ×16, `.workspace-shell` ×14. La última declaración gana.
- **Dónde.** `layout.css` líneas dispersas (ej.: `.inspector-tabs` en líneas 698 y 1437 con grid-template-columns y padding distintos).
- **Por qué importa.** Fuente de verdad ambigua. Si un dev edita la primera ocurrencia, no tiene efecto. Es el segundo factor de "puede romper la GUI" porque el comportamiento actual depende del orden de aparición, no de la intención.
- **Recomendación.** Después de partir `layout.css` (SEV-1.1) cada selector debe declararse **exactamente una vez**. Variantes se manejan con modifiers (`--ux`, `--floating`, `is-active`). Lint `stylelint` con `no-duplicate-selectors`.

### SEV-1.6 — 93 inline-styles en JSX dispersos
- **Qué.** `grep style={{ src/inspector src/app/shell src/timeline` → 93 ocurrencias. Patrones más frecuentes: `marginTop: 10`, `justifyContent: 'space-between'`, `border: '1px solid rgba(255,255,255,.08)', borderRadius: 12, padding: 10` (este último aparece literal en al menos 6 archivos).
- **Dónde.** Distribuido por inspector sections, left-rail, timeline.
- **Por qué importa.** Imposible cambiar la apariencia central desde un solo lugar. Cualquier ajuste de tono visual implica grep + 93 ediciones. No hay "el estilo aprovechado al 100% con el framework".
- **Recomendación.**
  - Extraer patrones a clases: `.tile-card`, `.row-between`, `.row-end`, `.stack-sm`, `.stack-md`.
  - **Después** del design system, prohibir `style={{ … }}` por lint salvo casos justificados (posiciones runtime de drag/drop, transform calculados, color de pixel runtime).

### SEV-1.7 — Tabs no son tabs (a11y rota)
- **Qué.** `<button className={tab === 'overview' ? 'primary' : 'ghost'}>` se usa como tab en `DocumentInspectorPanel`, `WidgetInspectorPanel`. **0 atributos `role="tab"`, `aria-selected`, `aria-controls`, `role="tablist"` en todo el codebase.**
- **Dónde.** `inspector-tabs` en panels, `chip-row`, `inspector-tabs` en widget.
- **Por qué importa.** Editor profesional sin a11y básica. Imposible navegación con teclado consistente, lectores de pantalla rompen, tab focus rings dependen de `:focus-visible` global.
- **Recomendación.** Componente `<Tabs>` con ARIA correcto, `aria-selected`, focus management con flechas izquierda/derecha. Ver SEV-1.4.

### SEV-1.8 — Document inspector tabs son enum cerrado, mientras los widget tabs son contract-driven
- **Qué.**
  - `DocumentInspectorTab = 'overview' | 'data' | 'collab'` — enum cerrado en TS.
  - `WidgetInspectorTabSpec` — contract-driven, declarativo en `WidgetDefinition`.
- **Dónde.** `src/inspector/sections/document/document-inspector-shared.ts` vs `src/widgets/registry/widget-definition.ts`.
- **Por qué importa.** Inconsistencia interna del propio sistema. Cada nuevo tab del lado documento toca dos archivos; cada nuevo tab de widget toca solo el `*.definition.ts`. El ecosistema crecerá del lado documento (Approvals, Audit, Variants globales, MRAID handoff, Compliance, Localization…) y mantener enum cerrado escala mal.
- **Recomendación.** Migrar `DocumentInspectorPanel` al mismo patrón que `WidgetInspectorPanel`: registry de tabs con `panels: DocumentInspectorPanelKey[]` y `register()`.

### SEV-1.9 — Whitelist de tipos de widget hardcoded en componentes UI
- **Qué.**
  ```ts
  // FillSection.tsx
  if (['image', 'hero-image', 'video-hero'].includes(widget.type)) { ... }
  // Stage.tsx openAssetPicker
  widget.type !== 'image' && widget.type !== 'hero-image' && widget.type !== 'video-hero'
    && widget.type !== 'image-carousel' && widget.type !== 'interactive-gallery'
    && widget.type !== 'shoppable-sidebar'
  // StageSelectionToolbar isMediaWidget
  widget.type === 'image' || widget.type === 'hero-image'
    || widget.type === 'video-hero' || widget.type === 'interactive-video'
  ```
- **Dónde.** `Stage.tsx`, `FillSection.tsx`, `StageSelectionToolbar.tsx`, varios renderers.
- **Por qué importa.** Cada widget nuevo "tipo media" obliga a tocar ≥3 archivos de UI. Rompe el principio "agregar widget = solo tocar `*.definition.ts`". Y la lista no es la misma en los tres lugares — drift garantizado.
- **Recomendación.** Capability flags en `WidgetDefinition`:
  ```ts
  capabilities?: {
    acceptsImageAsset?: boolean;
    acceptsVideoAsset?: boolean;
    acceptsAssetSwap?: boolean; // → muestra el botón Replace en SelectionToolbar
    hasFill?: boolean;          // → muestra FillSection
    hasAccentColor?: boolean;
    isMedia?: boolean;
  };
  ```
  La UI consulta `definition.capabilities.*`, nunca el `widget.type`.

### SEV-1.10 — Sizes del shell hardcoded en JSX inline-style
- **Qué.**
  ```tsx
  // StudioShell.tsx
  gridTemplateColumns: `${leftRailHidden ? '0px' : `${leftRailWidth}px`} minmax(0, 1fr) ${rightInspectorHidden ? '0px' : '328px'}`,
  gridTemplateRows: `64px minmax(0, 1fr) ${timelineHidden ? '0px' : `${timelineHeight}px`}`,
  ```
  - 64 px topbar, 328 px inspector, 260 px timeline, 288 px left rail default, [200..520] rango.
- **Dónde.** `src/app/shell/StudioShell.tsx` (constants TS) + `src/shared/layout.css` (grid areas).
- **Por qué importa.**
  - Inspector NO se puede resize (asimetría — left rail y timeline sí).
  - Estado de dimensiones NO persiste entre sesiones.
  - Doble fuente de verdad (TS + CSS).
- **Recomendación.**
  - Mover sizes a CSS variables aplicadas al root: `--shell-left-w`, `--shell-right-w`, `--shell-top-h`, `--shell-bottom-h`. Resize handlers actualizan vars.
  - Inspector resizable.
  - Persistir en localStorage (clave `smx.studio.shell.layout.v1`) y opcionalmente en server preferences cuando exista.

---

## 3. Hallazgos SEV-2 (deuda visible para usuario rich-media)

### SEV-2.1 — Widget Library sin previews
- **Qué.** En `WidgetLibrarySection`, cada módulo se muestra como tarjeta de **solo texto** (label + tipo + categoría).
- **Por qué importa.** Celtra, Connected Stories y Studio (Marpipe) muestran thumbnail por widget. El usuario rich-media descubre módulos visualmente, no leyendo nombres. Disminuye la curva de aprendizaje y aumenta velocidad.
- **Recomendación.**
  - Añadir `WidgetDefinition.thumbnail` (URL/SVG/data-uri opcional).
  - Si falta, generar miniatura procedural a partir de `defaults` en un canvas off-screen 96×64 (one-time cache).
  - Layout grid 2 columnas con preview arriba y label abajo.

### SEV-2.2 — Layers panel duplicado / huérfano
- **Qué.** El tab "Layers" del left rail dice literalmente "Timeline owns layers" y muestra solo Group/Ungroup + lista textual de selección.
- **Por qué importa.** Cognitivamente confunde: el usuario abre "Layers" y le dicen "ve a otro lado". Es deuda heredada de un refactor (S55 según el audit). Hoy compite con timeline track header.
- **Recomendación.**
  - Decidir: o (a) eliminar el tab y mover Group/Ungroup al menú contextual + selection toolbar, o (b) convertir Layers en un panel de **outline jerárquico** (árbol con scenes → widgets → grupos), drag-to-reorder, multi-select. Recomiendo (b) porque es lo que hacen Figma/Celtra y es el patrón natural.

### SEV-2.3 — Story Flow sin visualización de flujo
- **Qué.** `StoryFlowSection` lista escenas como cards verticales con texto "Next: …" y branches indentadas. No hay grafo.
- **Por qué importa.** Connected Stories y Celtra Story Flow muestran nodes + edges (drag-and-drop). Un story con 5 escenas y 3 branches por escena se vuelve ilegible en formato lista.
- **Recomendación.** Vista canvas de nodos (similar a n8n / ReactFlow). El componente sería `<StoryFlowCanvas>` con `nodes: Scene[]`, `edges: SceneTransition[]`. Lazy-loaded para no inflar el bundle.

### SEV-2.4 — Edit-mode no tiene wireframe rendering real
- **Qué.** `.stage-widget.is-edit-mode .stage-widget-content` solo aplica `border: 1px dashed`. El widget se sigue renderizando con su contenido real.
- **Por qué importa.** Editar el layout de un banner con 12 widgets que cargan video, mapa Leaflet, animaciones y fuentes pesadas es lento y distractor. Edit-mode debería mostrar una abstracción simplificada (rect + label + tipo).
- **Recomendación.** Cuando `previewMode === false`:
  - Renderer expone `renderWireframe(node)` opcional en `WidgetDefinition` (default = rect + label).
  - Stage usa `renderWireframe` por defecto, switch a `renderStage` sólo en preview o cuando el widget está seleccionado.
  - Hotkey `W` toggle wireframe global.

### SEV-2.5 — Iconos en modo "collapsed" del Floating Toolbar son letras
- **Qué.** Cuando `toolbarCollapsed === true`, los botones quedan como `R` (Rulers) y `B` (Badges). Letras no son iconos.
- **Recomendación.** Iconos del set unificado (SEV-1.3) tanto en estado expandido como colapsado.

### SEV-2.6 — TopBar centro casi vacío
- **Qué.** El bloque central del TopBar tiene un solo botón "Library". El resto del centro está vacío. El topbar tiene 64 px de alto desperdiciado.
- **Por qué importa.** El centro del topbar es real estate prime. Ahí pueden vivir: project name (hoy en izq), scene quick-switcher, breadcrumb, status pill global.
- **Recomendación.** Layout 3 zonas:
  - **Izquierda:** Back button + project name + dirty indicator.
  - **Centro:** Scene switcher + breadcrumb (`Project / Scene`) + canvas size pill.
  - **Derecha:** Preview + Export menu + Share + Publish + Save + status dot.

### SEV-2.7 — Asset Library Modal usa glyphs y depende del modal pesado
- **Qué.** `AssetLibraryModal.tsx` (472 líneas) maneja folders, drop zones, multi-select. Usa `▾ ▸ ✕ ▣` como iconos.
- **Por qué importa.** Es el lugar donde el usuario pasa más tiempo después del canvas. Tiene que sentirse de clase mundial.
- **Recomendación.** Migración 1-a-1 a iconos del set (SEV-1.3). Considerar drawer en vez de modal para no robar foco de canvas.

### SEV-2.8 — Botones reused como tabs (estado visual ambiguo)
- **Qué.** En el panel inspector, los tabs son `<button className={tab === id ? 'primary' : 'ghost'}>`. El estado activo es visualmente "botón verde primario" (CTA). Eso entra en conflicto con el botón "Save" que también es `primary` (verde).
- **Por qué importa.** Dos elementos verdes intensos compitiendo por jerarquía visual.
- **Recomendación.** Componente `<Tabs>` con tratamiento visual propio (subline + filled/unfilled, no verde brillante).

### SEV-2.9 — Selection toolbar usa SVG inline duplicado
- **Qué.** `StageSelectionToolbar.tsx` define localmente `EyeIcon`, `LockIcon`, `UploadIcon`, `LibraryIcon`, `LayerDownIcon`, `LayerUpIcon`, `DeleteIcon`, `DuplicateIcon`, `PlaceholderIcon`. Bien hecho, pero aislado.
- **Recomendación.** Mover al icon set centralizado y borrar las definiciones locales.

### SEV-2.10 — Panel state no persiste
- **Qué.** Estado de "left rail hidden", "inspector hidden", "timeline hidden", "timeline height", "left rail width" se reinicia en cada montaje de `StudioShell`.
- **Por qué importa.** El usuario que arma 20 banners por día necesita su layout pegado.
- **Recomendación.** Persist a localStorage con clave versionada `smx.studio.layout.v1`. Mismo flow propuesto en SEV-1.10.

---

## 4. Hallazgos SEV-3 (mejoras de calidad)

### SEV-3.1 — Solo el LeftRail es resizable; el Inspector no
- Asimetría. Inspector debería ser resizable también, con rango análogo (280–520 px).

### SEV-3.2 — `BACKGROUND_SWATCHES` hardcoded en `Stage.tsx`
- ```ts
  const BACKGROUND_SWATCHES = ['#111827', '#ffffff', '#0f172a', '#f59e0b', '#ef4444', '#2563eb'] as const;
  ```
- Mover a `domain/document/canvas-presets.ts` o a un hook `useCanvasSwatches()` que lea de tokens + branding cliente.

### SEV-3.3 — Falta opacity / rotation / lock-aspect en PositionSection
- Editor profesional necesita estos campos. Son una hora de trabajo.

### SEV-3.4 — `clampToolbarPosition` magic numbers (`240, 130, 520, 68, 176`)
- Dependen del ancho real del toolbar; deberían ser medidos con ResizeObserver, no hardcodeados.

### SEV-3.5 — Login screen mezcla idiomas (ES/EN)
- "Login cloud-native con sesiones reales" + "Remember session creates a persistent server session". Decidir un idioma o i18n real con `react-intl`/`lingui`.

### SEV-3.6 — Hash routing custom
- Funciona, pero limita deep-linking, history API moderna, breadcrumbs, share URLs estables. Considerar migrar a React Router cuando se invierta tiempo en routing (no urgente).

### SEV-3.7 — `DocumentInspectorPanel` con `showFeedCatalog` empty state poco accionable
- "Feed catalog is not available for X. Switch to IAB HTML5…" — debería incluir un botón directo "Switch to IAB HTML5" en vez de obligar al usuario a navegar al release section.

### SEV-3.8 — Transitions sin escala
- Valores en CSS: `.14s, .16s, .18s, .22s` mezclados. Tokens `--motion-fast: 120ms, --motion-base: 160ms, --motion-slow: 220ms`.

### SEV-3.9 — Falta sistema de tooltips
- `title` HTML nativo se usa por todos lados. No es accesible (no funciona en touch, no estilizable). Componente `<Tooltip>` con Radix-style positioning o propio.

### SEV-3.10 — Falta sistema de toasts/notifications
- Save status se muestra como `<span>` con colores. No hay feedback consistente para export OK, publish OK, error de red, conflict de versión.

---

## 5. Resumen ejecutivo de la "calidad-Celtra"

Para llegar al nivel del benchmark (Celtra / Connected Stories / Marpipe Studio):

| Dimensión | Hoy | Gap | Prioridad |
|---|---|---|---|
| Foundations (tokens, escala) | 8 vars CSS | Necesita 60+ tokens | SEV-1 |
| Icon system | Glyphs Unicode | Set único SVG | SEV-1 |
| Component library | 1 componente | 12+ primitivos | SEV-1 |
| Pixel-perfect (CSS único, sin duplicados) | 778 selectores caóticos | Reorganizar por dominio | SEV-1 |
| Z-index / layering | 18 valores ad-hoc | Escala fija de 8 niveles | SEV-1 |
| Widget Library UX | Solo texto | Thumbnails / preview | SEV-2 |
| Story Flow UX | Lista textual | Canvas de nodos | SEV-2 |
| Layers UX | Tab huérfano | Outline jerárquico | SEV-2 |
| Edit mode visual | Border dashed | Wireframe rendering | SEV-2 |
| A11y | 0 ARIA tabs | Tabs/Menu accesibles | SEV-1 |
| Persistencia layout | No | localStorage versionado | SEV-2 |
| Iconos en collapsed mode | Letras | Iconos | SEV-2 |
| TopBar density | Centro vacío | Reorganización 3 zonas | SEV-2 |

El plan de tickets — con orden, agrupación, criterios de aceptación y guardrails para que CODEX no rompa nada — está en el documento adjunto:

📄 **`STUDIO-CODEX-IMPLEMENTATION-PLAN-2026-05-08.md`**.
