# Auditoría del entregable de Codex — Studio Frontend Plan

**Fecha:** 2026-05-08
**Paquete auditado:** `studio-frontend-audit-package-2026-05-08.zip`
**Plan de referencia:** `STUDIO-CODEX-IMPLEMENTATION-PLAN-2026-05-08.md`
**Codex declara:** 97-98% completo · 49 test files · 212 tests pasando

> **Veredicto en una línea.** Codex entregó **arquitectónicamente bien**: los 11 sprints existen, los componentes prometidos están creados, las migraciones target están hechas. **Pero hay tres deudas reales que matizan ese 97%**: (1) los tokens de color son indexados por alpha (`--white-a-08`) en vez de semánticos, (2) **180 rgba sueltos** todavía en CSS de dominio, (3) el guardrail de stylelint quedó al 30% del plan. Resultado: el editor está mejor, pero la deuda **puede volver a crecer** porque el lint no la atrapa. Cuestión de un día de trabajo de Codex para cerrarlo.

---

## 1. Resumen por sprint

| Sprint | Estado real | Nota |
|---|---|---|
| **S1** Tokens + split CSS + stylelint | 🟡 **80%** | Tokens y split bien; stylelint muy laxo |
| **S2** Icon system | ✅ **100%** | lucide-react, 0 glyphs en UI shell |
| **S3** Component primitives | ✅ **95%** | 9 primitivos, ARIA en Tabs, 13 inline styles legítimos |
| **S4** Shell vars + persist | ✅ **100%** | Inspector resizable, layout persiste, scoped storage |
| **S5** Document inspector registry | ✅ **100%** | Registry contract-driven, mejor que el spec (panel-level visibility) |
| **S6** Capabilities en widgets | ✅ **95%** | Whitelists target removidas; quedan en export (zona protegida) y analytics |
| **S7** Widget thumbnails | ✅ **100%** | 11 thumbnails (top-list completo) + PlaceholderThumb |
| **S8** Edit-mode wireframe | ✅ **100%** | Toggle, atajo W, persist |
| **S9** Story Flow canvas | ✅ **100%** | 262 LoC vanilla, drag, persist, edges bezier |
| **S10** Layers outline | ✅ **100%** | Outline jerárquico, drag-reorder, ARIA |
| **S11** Polish | ✅ **90%** | TopBar 3 zonas, Tooltip, Toast, Position+Op/Rot/Lock, swatches a config |

**Resumen:** 9/11 sprints al 100%. S1 y S6 tienen deudas que detallo abajo.

---

## 2. Métricas plan vs entregable

| Métrica | Hoy estaba | Objetivo plan | **Real** | ✓ |
|---|---|---|---|---|
| Líneas máximas en archivo CSS | 4 005 | < 800 | **768** (stage.css) | ✅ |
| Selectores base duplicados | ~100 | 0 | **0** | ✅ |
| Hex/rgba sueltos en CSS dominio | 301 hex + ? rgba | 0 | **8 hex + 180 rgba** | ❌ |
| Glyphs Unicode en UI shell | ~30 | 0 | **0** | ✅ |
| Componentes en `src/shared/ui/` | 1 | ≥ 10 | **9** | 🟡 (1 corto) |
| `style={{...}}` en dirs target | 93 | < 25 | **13** | ✅ |
| Roles ARIA tabs/role | 0 | ≥ 4 | **9** | ✅ |
| Z-index literals altos en CSS | 18 | 0 | **0** (quedan 0/1/2 triviales) | ✅ |
| `!important` en CSS | 4 | 0 | **0** | ✅ |
| Whitelist `widget.type` en UI | 6+ | 0 | **0 en target sites** | ✅ |
| Layout persiste sesiones | No | Sí | **Sí** | ✅ |
| Inspector resizable | No | Sí | **Sí** | ✅ |
| Widget Library con thumbnails | No | Sí | **Sí (11 widgets)** | ✅ |
| Wireframe rendering | No | Sí | **Sí + atajo W** | ✅ |
| Story Flow canvas visual | No | Sí | **Sí** | ✅ |

**8 de 12 métricas cumplidas estrictamente. 1 cumplida parcial. 1 NO cumplida (rgba sueltos).**

---

## 3. Hallazgos críticos (lo que debes decirle a Codex que cierre)

### CRÍTICO-1 — Tokens de color indexados por alpha en lugar de semánticos

**Qué.** En `theme.css` Codex creó tokens así:

```css
--white-a-02: rgba(255, 255, 255, 0.02);
--white-a-03: rgba(255, 255, 255, 0.03);
--white-a-04: rgba(255, 255, 255, 0.04);
...
--white-a-96: rgba(255, 255, 255, 0.96);
```

Hay ~30 variantes de white-a, ~12 de black-a, ~6 de stroke-a, ~12 de accent-a, ~12 de focus-a, etc. **Total: ~100 tokens "alpha-indexados".**

**Por qué importa.** Son strings sintácticamente diferentes pero **semánticamente idénticos al rgba crudo**. Cambiar el tono visual de "todos los borders sutiles" sigue requiriendo grep + 18 ediciones, exactamente igual que antes. **Esto NO es un design system, es un compresor de strings.**

El plan pedía tokens **semánticos** del estilo:
```css
--border-subtle: var(--white-a-08);   /* 1 token, N usos */
--border-emphasis: var(--white-a-12);
--bg-overlay-low: var(--white-a-03);
--bg-overlay-med: var(--white-a-06);
--surface-hover: var(--white-a-08);
```

**Acción para Codex.** Crear capa **semántica** en `theme.css` debajo de los alpha-indexados (ya están bien como capa primitiva), y migrar consumers a la capa semántica. Estimado: 4–6 horas. Tabla mínima:

| Token semántico | = Primitivo |
|---|---|
| `--border-subtle` | `var(--white-a-08)` |
| `--border-emphasis` | `var(--white-a-12)` |
| `--border-strong` | `var(--white-a-18)` |
| `--bg-overlay-low` | `var(--white-a-03)` |
| `--bg-overlay-med` | `var(--white-a-06)` |
| `--bg-overlay-high` | `var(--white-a-12)` |
| `--shadow-color-soft` | `var(--black-a-12)` |
| `--shadow-color-base` | `var(--black-a-18)` |
| `--shadow-color-strong` | `var(--black-a-28)` |
| `--accent-bg-soft` | `var(--accent-a-12)` |
| `--accent-bg-active` | `var(--accent-a-22)` |
| `--accent-border-soft` | `var(--accent-a-34)` |
| `--accent-border-strong` | `var(--accent-a-45)` |

### CRÍTICO-2 — 180 rgba sueltos persisten en CSS de dominio

**Qué.** Pese a la tokenización masiva, hay **180 `rgba(...)` literales únicos** en los archivos de `src/shared/styles/`. Ejemplos:

```css
/* topbar.css:40 */
background: linear-gradient(135deg, rgba(245,165,36,.18), rgba(124,92,255,.16));
/* topbar.css:148 */
.status-metric { border:1px solid rgba(255,255,255,.08); ... }
/* components.css:32 */
background: linear-gradient(180deg, var(--accent-2), #1da774);
```

Y 8 hex sueltos: `#1da774, #1c2934, #ffd3d3, #ffb1b1, #7c9cff, #93a0bd, #f4f0e8, #1b2428`.

**Por qué importa.** El plan pidió 0. Cualquier rgba/hex que se quede afuera **es deuda nueva** y no la atrapa el lint actual. En 3 sprints más se vuelve a 200+.

**Acción para Codex.**
1. Tokenizar los 8 hex (varios son de `Button.tsx` del plan — el plan ya tenía la falla de no tokenizarlos).
2. Pasar los 180 rgba a tokens (algunos ya tienen su variante alpha-indexada, otros requieren añadir un token nuevo).
3. **Configurar stylelint para bloquearlos** — ver CRÍTICO-3.

### CRÍTICO-3 — Stylelint config al 30% del plan

**Qué.** El plan especificó esta config:

```js
{
  extends: ['stylelint-config-standard'],
  plugins: ['stylelint-declaration-strict-value'],
  rules: {
    'no-duplicate-selectors': true,
    'declaration-no-important': true,
    'scale-unlimited/declaration-strict-value': [
      ['/color$/', 'fill', 'stroke', 'background-color', 'border-color',
       'z-index', 'border-radius', 'font-size'],
      { ignoreValues: [...], message: 'Use a CSS custom property...' }
    ],
    'declaration-property-value-disallowed-list': {
      'transition': ['/[0-9]+ms/', '/[0-9]\\.[0-9]+s/']
    }
  }
}
```

Codex implementó:

```js
{
  rules: {
    'no-duplicate-selectors': true,
    'declaration-no-important': true,
  }
}
```

Faltan: `extends: stylelint-config-standard`, `stylelint-declaration-strict-value`, las dos reglas críticas de strict-value y disallowed-list. Y no instaló `stylelint-declaration-strict-value` como devDep.

**Por qué importa.** Sin estas reglas, **no hay barrera contra regresión**. Cualquier dev (o futuro Codex) puede meter `color: #ff0` o `transition: 200ms ease` y nadie se entera. Es exactamente la condición que generó el `layout.css` original de 4 005 líneas.

**Acción para Codex.**
- Instalar `stylelint-declaration-strict-value`.
- Aplicar la config completa del plan.
- Correr `pnpm lint:css` y arreglar las violaciones (que serán las de CRÍTICO-2).
- Integrar `lint:css` en CI antes de `build`.

---

## 4. Hallazgos secundarios (SEV-2/SEV-3)

### SEV-2.1 — Z-index escala híbrida

```css
--z-base: 0;
--z-backdrop: 1;
--z-raised: 2;
--z-stage-ui: 3;
--z-stage-overlay: 4;
--z-floating: 5;
--z-drop: 9;
--z-selection-toolbar: 12;
--z-collapsed-tab: 30;
--z-topbar: 40;
--z-sticky: 200;
--z-popover: 800;
--z-selection: 999;          /* ⚠ 999 es exactamente el valor mágico que el plan vetó */
--z-modal: 1200;
--z-playhead: 1500;
--z-toast: 1600;
--z-top: 2000;
```

El plan pedía 8 niveles consistentes (`base, raised, sticky, floating, popover, modal, toast, top`). Codex hizo 17 niveles mezclando escalas (1, 2, 3, 4, 5, 9, 12, 30, 40, 200, 800, 999, 1200, 1500, 1600, 2000).

**Acción.** Consolidar a 8 niveles con espaciado 100. La escala actual funcionará pero invita drift cuando agreguen un nuevo overlay.

### SEV-2.2 — `--motion-base` vs `--motion-slow` choque con plan

El plan: `--motion-fast: 120ms, --motion-base: 160ms, --motion-slow: 220ms`.
Real: `--motion-fast: 120ms, --motion-base: 160ms, --motion-slow: 180ms, --motion-slower: 220ms`.

Diferencia menor pero **rompe el contrato del plan** (alguien en sprint 12 usará `--motion-slow` esperando 220ms y obtendrá 180ms). Decisión: o se renombra `--motion-slower` → `--motion-slow` (y elimina el de 180ms), o se documenta el mapping.

### SEV-2.3 — Constantes MIN/MAX duplicadas en shell

`StudioShell.tsx` (líneas 15-20) y `use-shell-layout.ts` (líneas 24-29) tienen **literalmente las mismas 6 constantes**:
```ts
LEFT_RAIL_MIN_WIDTH = 200;
LEFT_RAIL_MAX_WIDTH = 520;
RIGHT_INSPECTOR_MIN_WIDTH = 280;
...
```

**Acción.** Mover al hook y exportarlas: `import { LEFT_RAIL_MIN_WIDTH, ... } from './use-shell-layout'`.

### SEV-2.4 — Tooltip inserta `aria-describedby` solo cuando `open`

```tsx
const child = cloneElement(children, {
  'aria-describedby': open ? tooltipId : undefined,
});
```

**Por qué importa.** Si un usuario navega con teclado y el `setOpen(true)` falla por race condition o focus rápido, el lector de pantalla NO anuncia la descripción. Mejor: setear `aria-describedby` siempre y mostrar/ocultar el bubble por `hidden`.

### SEV-2.5 — Toast `setTimeout` no se cancela en unmount

```tsx
globalThis.setTimeout(() => dismissToast(id), input.durationMs ?? 4200);
```

No hay cleanup. Si el provider se desmonta antes del timeout, hay memory leak (y posible warning de "setState on unmounted component"). 5 líneas para arreglar con un `useRef<Map<id, timeoutId>>`.

### SEV-2.6 — Toast usa `×` Unicode literal en dismiss

Después de migrar todo el shell a iconos, el botón dismiss del toast usa `×` (símbolo multiplicación). Inconsistencia. Reemplazar con `<StudioIcon icon={StudioIcons.close} size={14} />`.

### SEV-3.1 — Whitelists `widget.type` residuales en export/analytics

Quedan 7 ubicaciones en `export/portable.ts`, `export/channel-compliance.ts`, `export/mraid-compatibility.ts`, `inspector/sections/document/VideoAnalyticsSection.tsx`. El plan declaró export como zona protegida, así que es esperable. Pero `VideoAnalyticsSection.filter(w => w.type === 'interactive-video')` puede migrar a `getCapability(def, 'isVideoAnalyticsSource')` o similar — work futuro, no urgente.

### SEV-3.2 — Magic numbers de toolbar fallback

```tsx
const [toolbarBounds, setToolbarBounds] = useState({ width: 520, height: 176 });
const nextX = Math.max(32, Math.round(workspaceViewport.width / 2 - 240));
```

Son los valores de fallback antes de que el ResizeObserver mida. El plan pedía eliminar magic numbers. Tras el primer paint son irrelevantes (se sobreescriben), pero conviene moverlos a constantes nombradas (`TOOLBAR_FALLBACK_WIDTH = 520, TOOLBAR_INITIAL_X_OFFSET = 240`).

### SEV-3.3 — Algunos widgets sin thumbnail aún

11 thumbnails para los más usados está OK para sprint 7. Pero `shape`, `badge`, `group`, `countdown`, `add-to-calendar`, `form`, `weather-conditions`, `tiktok-video`, `four-faces`, `interactive-gallery`, etc. siguen usando el `PlaceholderThumb` por categoría. No es bloqueante (el placeholder se ve OK), pero el plan implicaba ir migrando todos.

### SEV-3.4 — `total CSS lines` creció

Pre-refactor: `theme.css` 153 + `layout.css` 4 005 = **4 158 líneas**.
Post-refactor: `theme.css` 427 + 11 archivos de dominio = **4 437 líneas**.

Diferencia: +279 líneas (+6.7%). Esperable porque tokens generan boilerplate, pero conviene revisar si hay duplicación entre `components.css` (293) y los archivos de dominio (`topbar.css` 400 con sus propios `.button` overrides).

---

## 5. Lo que Codex hizo MEJOR que el plan

Justo es decirlo:

1. **`document-inspector-registry`** añade `visible?` a panel-level además de tab-level — más capable.
2. **`DocumentInspectorPanel`** envuelve el contenido en `<section role="tabpanel" aria-labelledby>` — mejor a11y que el spec.
3. **`use-shell-layout`** usa `readScopedStorageItem` con un `'persistent'` scope — más robusto que `localStorage` directo.
4. **`getAcceptedAssetKinds`** es un helper extra de capabilities que no estaba en el plan pero suma.
5. **Layers outline** soporta navegación con flechas (Arrow Left/Right colapsa/expande grupos) — no estaba en el plan.
6. **`PositionSection.lockAspectRatio`** preserva el aspect ratio en TIEMPO REAL al editar W o H — implementación matemáticamente correcta, no trivial.

---

## 6. Plan de cierre (1 día de trabajo de Codex)

Para llegar al 100% real, Codex tiene que ejecutar este mini-sprint S12:

```
S12-T1  [4-6h]  Capa semántica de tokens de color sobre alpha-indexados
                + migrar consumers de los 13 tokens más usados
                → cierra CRÍTICO-1
S12-T2  [3-4h]  Tokenizar los 8 hex y 180 rgba sueltos
                → cierra CRÍTICO-2
S12-T3  [1-2h]  Config completo de stylelint (extends + strict-value + disallowed-list)
                + integrar en CI
                → cierra CRÍTICO-3
S12-T4  [30min] Consolidar Z-index a 8 niveles, reemplazar 999 con --z-selection: 1000
S12-T5  [30min] Mover MIN/MAX shell constants a use-shell-layout y exportar
S12-T6  [15min] Tooltip: aria-describedby siempre presente + hidden=true cuando open=false
S12-T7  [30min] Toast: cleanup de setTimeout en unmount + reemplazar × por icon
S12-T8  [10min] Renombrar --motion-slow → 220ms (eliminar el de 180 o renombrarlo a algo distinto)
```

**Total estimado: 10-13 horas. Un día.**

Después de S12, el plan estará al **100% real** y la deuda no podrá volver a crecer porque el lint la atrapa.

---

## 7. Recomendación final

**Aceptar el entregable de Codex con condicional de cierre S12.**

Lo entregado es **trabajo de calidad senior**: el grueso del plan está bien hecho, la a11y mejoró, el editor escaló. Pero el "97-98%" de Codex es real **estructuralmente** y optimista **en deuda de detalle**. Las tres deudas críticas (tokens semánticos, rgba sueltos, stylelint laxo) son la diferencia entre **"refactor que aguanta 6 meses sin recaer"** y **"refactor cosmético que regresa al estado original en 3 sprints"**.

S12 cierra eso en un día. No es opcional — es lo que valida la inversión de los 11 sprints anteriores.
