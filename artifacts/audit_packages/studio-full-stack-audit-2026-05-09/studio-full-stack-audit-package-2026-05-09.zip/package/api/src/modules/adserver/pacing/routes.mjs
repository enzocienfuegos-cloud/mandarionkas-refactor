import { badRequest, sendJson, serviceUnavailable, unauthorized } from '../../../lib/http.mjs';
import {
  getCampaignPacingBreakdown,
  listWorkspacePacingAlerts,
  listWorkspacePacingCampaigns,
} from '@smx/db/src/pacing.mjs';
import { withReadOnlySession } from '../../../lib/session.mjs';

export async function handlePacingRoutes(ctx) {
  const { method, pathname, requestId, res, url } = ctx;

  if (method === 'GET' && pathname === '/v1/pacing') {
    return withReadOnlySession(ctx, async (session) => {
      const campaigns = await listWorkspacePacingCampaigns(session.client, session.session.activeWorkspaceId);
      return sendJson(res, 200, { campaigns, requestId });
    });
  }

  if (method === 'GET' && pathname === '/v1/pacing/alerts') {
    return withReadOnlySession(ctx, async (session) => {
      const alerts = await listWorkspacePacingAlerts(session.client, session.session.activeWorkspaceId);
      return sendJson(res, 200, { alerts, requestId });
    });
  }

  if (method === 'GET' && /^\/v1\/pacing\/[^/]+\/breakdown$/.test(pathname)) {
    return withReadOnlySession(ctx, async (session) => {
      const campaignId = pathname.split('/')[3];
      if (!campaignId) return badRequest(res, requestId, 'Campaign id is required.');
      const breakdown = await getCampaignPacingBreakdown(
        session.client,
        session.session.activeWorkspaceId,
        campaignId,
        { days: url.searchParams.get('days') },
      );
      return sendJson(res, 200, { breakdown, requestId });
    });
  }

  return false;
}
