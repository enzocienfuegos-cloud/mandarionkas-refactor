import { getPool } from '@smx/db/src/pool.mjs';
import { resolveActiveCreativeForTag as resolveActiveCreativeForTagRows } from '@smx/db/src/tags.mjs';
import { wrapTrackedClickUrlWithDspMacro } from '../../../../../../packages/contracts/src/dsp-macros.mjs';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function trimText(value) {
  return String(value ?? '').trim();
}

function isValidTagId(id) {
  return UUID_RE.test(String(id ?? ''));
}

function escapeScriptContext(jsonStr) {
  return jsonStr.replace(/<\//g, '<\\/');
}

function resolveBaseUrl(ctx) {
  const explicit = trimText(ctx.env.apiBaseUrl || ctx.env.apiPublicBaseUrl || ctx.env.baseUrl);
  if (explicit) return explicit.replace(/\/+$/, '');
  const protocol = trimText(ctx.req.headers['x-forwarded-proto']) || 'https';
  const host = trimText(ctx.req.headers['x-forwarded-host'] || ctx.req.headers.host);
  return host ? `${protocol}://${host}` : 'https://localhost';
}

function getDatabasePool(env) {
  const cs = trimText(env.databasePoolUrl || env.databaseUrl);
  return cs ? getPool(cs) : null;
}

function applyPublicCors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.removeHeader('Access-Control-Allow-Credentials');
  res.removeHeader('Vary');
}

function sendHtml(res, html, status = 200) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.setHeader('Content-Security-Policy', "frame-ancestors *");
  res.removeHeader('X-Frame-Options');
  res.end(html);
  return true;
}

function sendJs(res, js, status = 200) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.end(js);
  return true;
}

export function pickWeightedCreativeRow(rows, random = Math.random) {
  const candidates = (Array.isArray(rows) ? rows : [])
    .filter((row) => trimText(row?.public_url))
    .map((row) => ({
      ...row,
      weight: Math.max(1, Number(row?.weight) || 1),
    }));

  if (!candidates.length) return null;
  if (candidates.length === 1) return candidates[0];

  const totalWeight = candidates.reduce((sum, row) => sum + row.weight, 0);
  let cursor = Math.max(0, Number(random()) || 0) * totalWeight;

  for (const row of candidates) {
    cursor -= row.weight;
    if (cursor < 0) return row;
  }

  return candidates[candidates.length - 1];
}

export function buildDisplayHtml({ creativeUrl, width, height, clickTrackerUrl, engagementTrackerUrl, impressionUrl, clickUrl, clickTag, omidVerification }) {
  const w = Number(width) || 300;
  const h = Number(height) || 250;
  const safeCreativeUrl = trimText(creativeUrl);
  const safeClickTracker = trimText(clickTrackerUrl);
  const safeEngagementTracker = trimText(engagementTrackerUrl);
  const safeImpression = trimText(impressionUrl);
  const safeClickUrl = trimText(clickUrl);

  if (!safeCreativeUrl) {
    return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="ad.size" content="width=${w},height=${h}">
<style>*{margin:0;padding:0}html,body{width:${w}px;height:${h}px;overflow:hidden;background:transparent}</style>
</head>
<body>
<!-- SMX: no active creative -->
</body>
</html>`;
  }

  const safeImpressionJs = safeImpression ? escapeScriptContext(JSON.stringify(safeImpression)) : null;
  const safeClickTrackerJs = safeClickTracker ? escapeScriptContext(JSON.stringify(safeClickTracker)) : 'null';
  const trackedClickTag = trimText(clickTag) || (
    safeClickTracker
      ? (safeClickUrl
          ? `${safeClickTracker}?url=${encodeURIComponent(safeClickUrl)}`
          : safeClickTracker)
      : safeClickUrl
  );
  const clickTagBlock = trackedClickTag
    ? `<script>var clickTag=${escapeScriptContext(JSON.stringify(trackedClickTag))};window.clickTag=clickTag;</script>`
    : '';
  const iframeSrc = `${safeCreativeUrl}${trackedClickTag ? `${safeCreativeUrl.includes('?') ? '&' : '?'}clickTag=${encodeURIComponent(trackedClickTag)}` : ''}`;
  const omidBlock = omidVerification?.jsUrl
    ? `<script src="https://staticresources.iab-psl.org/omid/omid-session-client.js" async></script>
<script>
(function(){
  if(typeof OmidSessionClient === 'undefined') return;
  var v = OmidSessionClient.default;
  var ctx = new v.Context(v.PartnerName('${omidVerification.vendor || 'SMX'}'), v.PartnerVersion('1.0'));
  var vRes = ${omidVerification.params ? escapeScriptContext(JSON.stringify(omidVerification.params)) : '{}'};
  ctx.setVerificationResources([{ vendorKey: '${omidVerification.vendor || 'smx'}', verificationParameters: JSON.stringify(vRes), resourceUrl: ${escapeScriptContext(JSON.stringify(omidVerification.jsUrl))} }]);
  new v.AdSession(ctx);
})();
</script>`
    : '';

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="ad.size" content="width=${w},height=${h}">
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:${w}px;height:${h}px;overflow:hidden;background:transparent}
iframe{border:0;display:block;width:100%;height:100%}
</style>
${clickTagBlock}
${omidBlock}
</head>
<body>
<iframe
  id="smx-creative-frame"
  src="${iframeSrc}"
  width="${w}"
  height="${h}"
  scrolling="no"
  frameborder="0"
  marginwidth="0"
  marginheight="0"
  allowfullscreen
  sandbox="allow-scripts allow-same-origin allow-popups allow-forms allow-top-navigation-by-user-activation"
></iframe>
<script>
(function(){
  ${safeImpressionJs ? `(new Image()).src = ${safeImpressionJs};` : '// impression suppressed'}

  var clickTracker = ${safeClickTrackerJs};
  var engagementTracker = ${safeEngagementTracker ? escapeScriptContext(JSON.stringify(safeEngagementTracker)) : 'null'};
  var injectedClickTag = ${trackedClickTag ? escapeScriptContext(JSON.stringify(trackedClickTag)) : 'null'};
  var frame = document.getElementById('smx-creative-frame');
  if (frame && injectedClickTag) {
    frame.addEventListener('load', function() {
      try {
        frame.contentWindow.postMessage(
          JSON.stringify({ type: 'smx:init', clickTag: injectedClickTag }),
          '*'
        );
      } catch(_) {}
    });
  }
  window.addEventListener('message', function(e) {
    try {
      var data = typeof e.data === 'string' ? JSON.parse(e.data) : e.data;
      if (!data || data.type !== 'smx:exit') return;
      var dest = (typeof data.url === 'string' && data.url) ? data.url : '';
      var resolvedClickUrl = dest || injectedClickTag || '';
      var navigateTo = resolvedClickUrl || clickTracker || '';
      var isAlreadyTracked = clickTracker && resolvedClickUrl && resolvedClickUrl.indexOf(clickTracker) === 0;
      if (clickTracker && !isAlreadyTracked) {
        var t = clickTracker + (clickTracker.indexOf('?') === -1 ? '?' : '&') + 'url=' + encodeURIComponent(resolvedClickUrl || clickTracker);
        try {
          fetch(t, { method: 'POST', keepalive: true, mode: 'no-cors', credentials: 'include' });
        } catch(_) {
          (new Image()).src = t;
        }
      }
      if (navigateTo) {
        try { window.top.location.href = navigateTo; } catch(_) { window.open(navigateTo, '_blank'); }
      }
    } catch(_) {}
  });

  (function() {
    if (!engagementTracker) return;

    var frame = document.getElementById('smx-creative-frame');
    var viewStart = null;
    var hoverStart = null;
    var flushed = false;

    function sendBeacon(url) {
      try {
        fetch(url, { method: 'GET', keepalive: true, mode: 'no-cors', credentials: 'include' });
      } catch(_) {
        (new Image()).src = url;
      }
    }

    function flushViewSegment() {
      if (!viewStart) return;
      var duration = Date.now() - viewStart;
      viewStart = null;
      if (duration > 0) {
        sendBeacon(engagementTracker + '?event=viewable&t=' + Math.round(duration));
      }
    }

    function flushHoverSegment() {
      if (!hoverStart) return;
      var duration = Date.now() - hoverStart;
      hoverStart = null;
      if (duration > 0) {
        sendBeacon(engagementTracker + '?event=hover_end&t=' + Math.round(duration));
      }
    }

    function flushActiveSegmentsIncrementally() {
      if (flushed) return;
      if (viewStart) {
        var viewDuration = Date.now() - viewStart;
        if (viewDuration > 0) {
          sendBeacon(engagementTracker + '?event=viewable&t=' + Math.round(viewDuration));
          viewStart = Date.now();
        }
      }
      if (hoverStart) {
        var hoverDuration = Date.now() - hoverStart;
        if (hoverDuration > 0) {
          sendBeacon(engagementTracker + '?event=hover_end&t=' + Math.round(hoverDuration));
          hoverStart = Date.now();
        }
      }
    }

    function flush() {
      if (flushed) return;
      flushed = true;
      flushViewSegment();
      flushHoverSegment();
    }

    if (frame && typeof IntersectionObserver !== 'undefined') {
      var isMRC = false;
      var mrcTimer = null;

      var observer = new IntersectionObserver(function(entries) {
        var ratio = entries[0].intersectionRatio;
        if (ratio >= 0.5) {
          if (!isMRC) {
            mrcTimer = setTimeout(function() {
              isMRC = true;
              viewStart = Date.now();
            }, 1000);
          }
        } else {
          clearTimeout(mrcTimer);
          mrcTimer = null;
          if (isMRC) flushViewSegment();
          isMRC = false;
        }
      }, { threshold: [0, 0.5, 1.0] });

      observer.observe(frame);
    }

    if (frame) {
      frame.addEventListener('mouseenter', function() {
        flushed = false;
        hoverStart = Date.now();
      });
      frame.addEventListener('mouseleave', function() {
        flushHoverSegment();
      });
    }

    window.addEventListener('pagehide', flush);
    window.addEventListener('beforeunload', flush);
    setInterval(flushActiveSegmentsIncrementally, 5000);
  })();
})();
</script>
</body>
</html>`;
}

export function buildDisplayJs({
  creativeUrl,
  impressionUrl,
  clickTrackerUrl,
  engagementTrackerUrl,
  clickTag,
  width,
  height,
}) {
  const w = Number(width) || 300;
  const h = Number(height) || 250;
  const safeCreativeUrl = escapeScriptContext(JSON.stringify(creativeUrl || ''));
  const safeImpression = impressionUrl ? escapeScriptContext(JSON.stringify(impressionUrl)) : 'null';
  const safeClickTracker = clickTrackerUrl ? escapeScriptContext(JSON.stringify(clickTrackerUrl)) : 'null';
  const safeEngagement = engagementTrackerUrl ? escapeScriptContext(JSON.stringify(engagementTrackerUrl)) : 'null';
  const safeClickTag = clickTag ? escapeScriptContext(JSON.stringify(clickTag)) : 'null';

  return `(function(){
  var creativeUrl       = ${safeCreativeUrl};
  var impressionUrl     = ${safeImpression};
  var clickTrackerUrl   = ${safeClickTracker};
  var engagementUrl     = ${safeEngagement};
  var clickTag          = ${safeClickTag};
  var W = '${w}'; var H = '${h}';

  if (!creativeUrl) return;

  var script = document.currentScript;
  if (!script) return;
  var parent = script.parentNode;
  if (!parent) return;

  if (impressionUrl) (new Image()).src = impressionUrl;

  if (clickTag) window.clickTag = clickTag;

  var src = creativeUrl;
  if (clickTag) {
    src = creativeUrl + (creativeUrl.indexOf('?') === -1 ? '?' : '&') + 'clickTag=' + encodeURIComponent(clickTag);
  }

  var iframe = document.createElement('iframe');
  iframe.src = src;
  iframe.width  = W;
  iframe.height = H;
  iframe.scrolling = 'no';
  iframe.frameBorder = '0';
  iframe.marginWidth  = '0';
  iframe.marginHeight = '0';
  iframe.style.border   = '0';
  iframe.style.overflow = 'hidden';
  iframe.style.display  = 'block';
  iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-popups allow-forms allow-top-navigation-by-user-activation');

  if (clickTag) {
    iframe.addEventListener('load', function() {
      try {
        iframe.contentWindow.postMessage(
          JSON.stringify({ type: 'smx:init', clickTag: clickTag }),
          '*'
        );
      } catch(_) {}
    });
  }

  window.addEventListener('message', function(e) {
    try {
      var data = typeof e.data === 'string' ? JSON.parse(e.data) : e.data;
      if (!data || data.type !== 'smx:exit') return;
      var dest = (typeof data.url === 'string' && data.url) ? data.url : '';
      var resolvedClickUrl = dest || clickTag || '';
      var navigateTo = resolvedClickUrl || clickTrackerUrl || '';
      var isAlreadyTracked = clickTrackerUrl && resolvedClickUrl && resolvedClickUrl.indexOf(clickTrackerUrl) === 0;
      if (clickTrackerUrl && !isAlreadyTracked) {
        var t = clickTrackerUrl + (clickTrackerUrl.indexOf('?') === -1 ? '?' : '&') + 'url=' + encodeURIComponent(resolvedClickUrl || clickTrackerUrl);
        try { fetch(t, { method: 'POST', keepalive: true, mode: 'no-cors', credentials: 'include' }); } catch(_) { (new Image()).src = t; }
      }
      if (navigateTo) {
        try { window.top.location.href = navigateTo; } catch(_) { window.open(navigateTo, '_blank'); }
      }
    } catch(_) {}
  });

  (function() {
    if (!engagementUrl) return;
    var viewStart = null; var hoverStart = null; var flushed = false;
    function sendBeacon(url) {
      try { fetch(url, { method: 'GET', keepalive: true, mode: 'no-cors', credentials: 'include' }); } catch(_) { (new Image()).src = url; }
    }
    function flushView() { if (!viewStart) return; var d = Date.now() - viewStart; viewStart = null; if (d > 0) sendBeacon(engagementUrl + '?event=viewable&t=' + Math.round(d)); }
    function flushHover() { if (!hoverStart) return; var d = Date.now() - hoverStart; hoverStart = null; if (d > 0) sendBeacon(engagementUrl + '?event=hover_end&t=' + Math.round(d)); }
    function flush() { if (flushed) return; flushed = true; flushView(); flushHover(); }
    if (typeof IntersectionObserver !== 'undefined') {
      var isMRC = false; var mrcTimer = null;
      new IntersectionObserver(function(entries) {
        var ratio = entries[0].intersectionRatio;
        if (ratio >= 0.5) { if (!isMRC) { mrcTimer = setTimeout(function() { isMRC = true; viewStart = Date.now(); }, 1000); } }
        else { clearTimeout(mrcTimer); mrcTimer = null; if (isMRC) flushView(); isMRC = false; }
      }, { threshold: [0, 0.5, 1.0] }).observe(iframe);
    }
    iframe.addEventListener('mouseenter', function() { flushed = false; hoverStart = Date.now(); });
    iframe.addEventListener('mouseleave', flushHover);
    window.addEventListener('pagehide', flush);
    window.addEventListener('beforeunload', flush);
    setInterval(function() {
      if (flushed) return;
      if (viewStart) { var d = Date.now() - viewStart; if (d > 0) { sendBeacon(engagementUrl + '?event=viewable&t=' + Math.round(d)); viewStart = Date.now(); } }
      if (hoverStart) { var d2 = Date.now() - hoverStart; if (d2 > 0) { sendBeacon(engagementUrl + '?event=hover_end&t=' + Math.round(d2)); hoverStart = Date.now(); } }
    }, 5000);
  })();

  parent.insertBefore(iframe, script);
  parent.removeChild(script);
})();`;
}

export async function handleDisplayRoutes(ctx) {
  const { method, pathname, res, req, env, url } = ctx;

  if (method === 'OPTIONS' && /^\/v1\/tags\/(display|native)\//.test(pathname)) {
    applyPublicCors(req, res);
    res.statusCode = 204;
    res.end();
    return true;
  }

  if (method === 'GET' && /^\/v1\/tags\/display\/[^/]+\.html$/.test(pathname)) {
    const rawId = pathname.split('/')[4].replace(/\.html$/, '');
    applyPublicCors(req, res);

    if (!isValidTagId(rawId)) {
      res.statusCode = 400;
      res.end();
      return true;
    }
    const tagId = rawId;

    const pool = getDatabasePool(env);
    const rows = await resolveActiveCreativeForTagRows(pool, tagId);
    const row = pickWeightedCreativeRow(rows);

    if (!row) {
      return sendHtml(res, '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body><!-- smx: no content --></body></html>');
    }

    const baseUrl = resolveBaseUrl(ctx);
    const DSP_TRACKER_KEYS = [
      'dsp', 'dom', 'purl', 'cuu', 'ifa', 'idfa', 'gadvid', 'iuid',
      'cmpid', 'netid', 'srcpubid', 'ppos', 'trftype', 'carr', 'appid',
      'appb', 'appn', 'excid', 'excpubid', 'excsiddmn', 'sdmn', 'sid',
      'cntlang', 'cnttitle', 'cntseries', 'cngen', 'ctxid', 'appstnm',
      'gdpr', 'gdpr_consent', 'us_privacy',
      'cb', 'tmp', 'cmpne', 'adgne', 'adgid', 'crene', 'wbrse', 'oprsye',
      'lcc', 'lclat', 'lclong', 'dtyp',
    ];
    const trackerParams = new URLSearchParams();
    for (const key of DSP_TRACKER_KEYS) {
      const val = url.searchParams.get(key);
      if (val !== null && val !== '') trackerParams.set(key, val);
    }
    const dspQuery = Object.fromEntries(url.searchParams.entries());
    const trackerSuffix = trackerParams.toString() ? `?${trackerParams.toString()}` : '';
    const suppressImpression = url.searchParams.get('smx_no_imp') === '1';
    const impressionUrl = suppressImpression
      ? ''
      : `${baseUrl}/v1/tags/tracker/${tagId}/impression.gif${trackerSuffix}`;
    const clickTrackerUrl = `${baseUrl}/v1/tags/tracker/${tagId}/click${trackerSuffix}`;
    const engagementTrackerUrl = `${baseUrl}/v1/tags/tracker/${tagId}/engagement`;
    const resolvedClickUrl = trimText(row.creative_click_url) || '';
    const baseClickTag = clickTrackerUrl
      ? (resolvedClickUrl
          ? `${clickTrackerUrl}${clickTrackerUrl.includes('?') ? '&' : '?'}url=${encodeURIComponent(resolvedClickUrl)}`
          : clickTrackerUrl)
      : resolvedClickUrl;
    const wrappedClickTag = wrapTrackedClickUrlWithDspMacro(baseClickTag, dspQuery, dspQuery.smx_dsp || dspQuery.dsp);

    const html = buildDisplayHtml({
      creativeUrl: row.public_url ?? '',
      width: row.width,
      height: row.height,
      clickTrackerUrl,
      engagementTrackerUrl,
      impressionUrl,
      clickUrl: resolvedClickUrl,
      clickTag: wrappedClickTag,
      omidVerification: {
        vendor: trimText(row.omid_verification_vendor),
        jsUrl: trimText(row.omid_verification_js_url),
        params: row.omid_verification_params,
      },
    });

    return sendHtml(res, html);
  }

  if (method === 'GET' && /^\/v1\/tags\/display\/[^/]+\.js$/.test(pathname)) {
    const rawId = pathname.split('/')[4].replace(/\.js$/, '');
    applyPublicCors(req, res);

    if (!isValidTagId(rawId)) {
      res.statusCode = 400;
      res.end();
      return true;
    }
    const tagId = rawId;

    const pool = getDatabasePool(env);
    const rows = await resolveActiveCreativeForTagRows(pool, tagId);
    const row = pickWeightedCreativeRow(rows);

    const baseUrl = resolveBaseUrl(ctx);
    const DSP_TRACKER_KEYS = [
      'dsp', 'dom', 'purl', 'cuu', 'ifa', 'idfa', 'gadvid', 'iuid',
      'cmpid', 'netid', 'srcpubid', 'ppos', 'trftype', 'carr', 'appid',
      'appb', 'appn', 'appne', 'excid', 'excpubid', 'excsiddmn', 'sdmn',
      'sid', 'cntlang', 'cnttitle', 'cntseries', 'cngen', 'ctxid', 'appstnm',
      'gdpr', 'gdpr_consent', 'us_privacy',
      'cb', 'tmp', 'cmpne', 'cmpgrpid', 'adgne', 'adgid', 'crene', 'cresze',
      'cretye', 'creid', 'wbrse', 'oprsye', 'lcc', 'lclat', 'lclong',
      'dtyp', 'lcst',
    ];
    const trackerParams = new URLSearchParams();
    for (const key of DSP_TRACKER_KEYS) {
      const val = url.searchParams.get(key);
      if (val !== null && val !== '') trackerParams.set(key, val);
    }
    const dspQuery = Object.fromEntries(url.searchParams.entries());
    const trackerSuffix = trackerParams.toString() ? `?${trackerParams.toString()}` : '';
    const width = row?.width || 300;
    const height = row?.height || 250;

    if (!row || !trimText(row.public_url)) {
      return sendJs(res, `(function(){
  var w='${width}',h='${height}';
  var script=document.currentScript;if(!script)return;
  var el=document.createElement('div');
  el.style.cssText='display:inline-block;width:'+w+'px;height:'+h+'px;background:transparent;';
  script.parentNode&&script.parentNode.insertBefore(el,script);
  script.parentNode&&script.parentNode.removeChild(script);
})();`);
    }

    const suppressImpression = url.searchParams.get('smx_no_imp') === '1';
    const impressionUrl = suppressImpression ? '' : `${baseUrl}/v1/tags/tracker/${tagId}/impression.gif${trackerSuffix}`;
    const clickTrackerUrl = `${baseUrl}/v1/tags/tracker/${tagId}/click${trackerSuffix}`;
    const engagementTrackerUrl = `${baseUrl}/v1/tags/tracker/${tagId}/engagement`;
    const resolvedClickUrl = trimText(row.creative_click_url) || '';
    const baseClickTag = clickTrackerUrl
      ? (resolvedClickUrl
          ? `${clickTrackerUrl}${clickTrackerUrl.includes('?') ? '&' : '?'}url=${encodeURIComponent(resolvedClickUrl)}`
          : clickTrackerUrl)
      : resolvedClickUrl;
    const clickTag = wrapTrackedClickUrlWithDspMacro(baseClickTag, dspQuery, dspQuery.smx_dsp || dspQuery.dsp);

    return sendJs(res, buildDisplayJs({
      creativeUrl: trimText(row.public_url),
      impressionUrl,
      clickTrackerUrl,
      engagementTrackerUrl,
      clickTag,
      width,
      height,
    }));
  }

  if (method === 'GET' && /^\/v1\/tags\/native\/[^/]+\.js$/.test(pathname)) {
    const rawId = pathname.split('/')[4].replace(/\.js$/, '');
    applyPublicCors(req, res);

    if (!isValidTagId(rawId)) {
      res.statusCode = 400;
      res.end();
      return true;
    }
    const tagId = rawId;

    const pool = getDatabasePool(env);
    const rows = await resolveActiveCreativeForTagRows(pool, tagId);
    const row = pickWeightedCreativeRow(rows);

    const baseUrl = resolveBaseUrl(ctx);
    const displayHtmlUrl = `${baseUrl}/v1/tags/display/${tagId}.html`;
    const width = row?.width || 300;
    const height = row?.height || 250;

    return sendJs(res, buildDisplayJs({
      creativeUrl: displayHtmlUrl,
      impressionUrl: '',
      clickTrackerUrl: '',
      engagementTrackerUrl: '',
      clickTag: '',
      width,
      height,
    }));
  }

  return false;
}
