module.exports = {
  rules: {
    'no-duplicate-selectors': true,
    'declaration-no-important': true,
  },
  ignoreFiles: ['**/node_modules/**', 'dist/**'],
};
