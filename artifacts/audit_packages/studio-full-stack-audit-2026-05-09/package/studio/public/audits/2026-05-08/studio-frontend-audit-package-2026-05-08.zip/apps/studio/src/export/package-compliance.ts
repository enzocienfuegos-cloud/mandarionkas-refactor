import type { ExportAssetPlanEntry } from './assets';
import type { ExportBundle } from './bundle';
import { buildExportPackageMetrics } from './package-metrics';
import type { ExportExitConfig, ExportPackagingPlan } from './packaging';
import type { PortableExportProject } from './portable';
import { getMraidProjectCompatibility } from './mraid-compatibility';
import type { MraidAdapterResult } from './adapters';

export type ExportPackageComplianceIssue = {
  level: 'error' | 'warning';
  code: string;
  message: string;
  targetId?: string;
  scope: 'bundle' | 'entry' | 'runtime' | 'asset' | 'exit' | 'packaging';
};

function getTotalBundleBytes(bundle: ExportBundle): number {
  const encoder = new TextEncoder();
  return bundle.files.reduce((sum, file) => sum + (file.bytes?.length ?? encoder.encode(file.content ?? '').length), 0);
}

function parsePortableProject(bundle: ExportBundle): PortableExportProject | null {
  const content = bundle.files.find((file) => file.path === 'portable-project.json')?.content;
  if (!content) return null;
  try {
    return JSON.parse(content) as PortableExportProject;
  } catch {
    return null;
  }
}

function parseMraidAdapter(bundle: ExportBundle): MraidAdapterResult | null {
  const content = bundle.files.find((file) => file.path === 'adapter.json')?.content;
  if (!content) return null;
  try {
    const parsed = JSON.parse(content) as MraidAdapterResult;
    return parsed.adapter === 'mraid' ? parsed : null;
  } catch {
    return null;
  }
}

export function validateExportPackage(
  bundle: ExportBundle,
  packagingPlan: ExportPackagingPlan,
  exitConfig: ExportExitConfig,
  assetPlan: ExportAssetPlanEntry[],
): ExportPackageComplianceIssue[] {
  const issues: ExportPackageComplianceIssue[] = [];
  const filePaths = bundle.files.map((file) => file.path);
  const duplicates = filePaths.filter((path, index) => filePaths.indexOf(path) !== index);
  const htmlFiles = filePaths.filter((path) => path.endsWith('.html'));
  const totalBytes = getTotalBundleBytes(bundle);
  const bundledAssetCount = assetPlan.filter((asset) => asset.strategy === 'bundled-copy').length;
  const remoteReferencedAssetCount = assetPlan.filter((asset) => asset.strategy === 'external-reference' && /^https?:\/\//i.test(asset.sourceUrl)).length;
  const materializedAssets = assetPlan.filter((asset) => filePaths.includes(asset.packagingPath));
  const packageMetrics = buildExportPackageMetrics(bundle, assetPlan);
  const clickTagChannel = bundle.channel === 'google-display' || bundle.channel === 'gam-html5';
  const mraidChannel = bundle.channel === 'mraid';
  const portableProject = mraidChannel ? parsePortableProject(bundle) : null;
  const mraidAdapter = mraidChannel ? parseMraidAdapter(bundle) : null;

  if (!bundle.files.length) {
    issues.push({
      level: 'error',
      code: 'bundle.empty',
      scope: 'bundle',
      message: 'Export bundle has no files.',
    });
    return issues;
  }

  duplicates.forEach((path) => {
    issues.push({
      level: 'error',
      code: 'bundle.duplicate-file',
      scope: 'bundle',
      targetId: path,
      message: `Export bundle contains duplicate path "${path}".`,
    });
  });

  packagingPlan.emittedFiles.forEach((path) => {
    if (!filePaths.includes(path)) {
      issues.push({
        level: 'error',
        code: 'packaging.missing-required-file',
        scope: 'packaging',
        targetId: path,
        message: `Packaging plan expects "${path}" but it is missing from the bundle.`,
      });
    }
  });

  if (!filePaths.includes(packagingPlan.entryFile)) {
    issues.push({
      level: 'error',
      code: 'entry.missing',
      scope: 'entry',
      targetId: packagingPlan.entryFile,
      message: `Package entry file "${packagingPlan.entryFile}" is missing.`,
    });
  }

  if (packagingPlan.requiresSingleRootDocument && htmlFiles.length !== 1) {
    issues.push({
      level: 'error',
      code: 'entry.multiple-html-files',
      scope: 'entry',
      message: 'Package requires a single root HTML document, but the bundle contains multiple HTML files.',
    });
  }

  if (filePaths.includes('index.html')) {
    const html = bundle.files.find((file) => file.path === 'index.html')?.content ?? '';
    if (!html.includes('./runtime.js')) {
      issues.push({
        level: 'warning',
        code: 'runtime.missing-script-reference',
        scope: 'runtime',
        targetId: 'index.html',
        message: 'index.html does not reference runtime.js.',
      });
    }
    if (clickTagChannel && !html.includes('window.ClickTag = window.ClickTag ||')) {
      issues.push({
        level: 'error',
        code: 'exit.clicktag-bootstrap-missing',
        scope: 'entry',
        targetId: 'index.html',
        message: `${bundle.channel} package is missing the clickTag bootstrap in index.html.`,
      });
    }
    if (mraidChannel && !html.includes('window.mraid') && !html.includes('window.smxMraidState')) {
      issues.push({
        level: 'error',
        code: 'runtime.mraid-bootstrap-missing',
        scope: 'runtime',
        targetId: 'index.html',
        message: 'mraid package is missing the MRAID bootstrap in index.html.',
      });
    }
  }

  if (packagingPlan.sceneCount > 1 && !filePaths.includes('runtime.js')) {
    issues.push({
      level: 'error',
      code: 'runtime.missing-runtime-js',
      scope: 'runtime',
      targetId: 'runtime.js',
      message: 'Multi-scene package is missing runtime.js.',
    });
  }

  if ((exitConfig.strategy === 'clickTag' || exitConfig.strategy === 'window-open' || exitConfig.strategy === 'mraid-open') && !exitConfig.primaryUrl) {
    issues.push({
      level: 'error',
      code: 'exit.missing-primary-url',
      scope: 'exit',
      message: `Exit strategy "${exitConfig.strategy}" requires a primary clickthrough URL.`,
    });
  }

  if (packagingPlan.exitStrategy !== exitConfig.strategy) {
    issues.push({
      level: 'warning',
      code: 'exit.strategy-mismatch',
      scope: 'exit',
      message: `Packaging exit strategy "${packagingPlan.exitStrategy}" does not match exit config "${exitConfig.strategy}".`,
    });
  }

  const assetPathSet = new Set<string>();
  assetPlan.forEach((asset) => {
    if (assetPathSet.has(asset.packagingPath)) {
      issues.push({
        level: 'error',
        code: 'asset.duplicate-packaging-path',
        scope: 'asset',
        targetId: asset.packagingPath,
        message: `Asset plan reuses packaging path "${asset.packagingPath}".`,
      });
    }
    assetPathSet.add(asset.packagingPath);
  });

  if ((bundle.channel === 'google-display' || bundle.channel === 'gam-html5') && assetPlan.length && packagingPlan.externalAssetMode === 'referenced') {
    issues.push({
      level: 'warning',
      code: 'asset.remote-reference-mode',
      scope: 'asset',
      message: 'Package still references remote assets. For stricter ad-hosting compatibility, prefer rewriting assets to local bundle paths.',
    });
  }

  if (bundle.channel === 'google-display' && remoteReferencedAssetCount > 0) {
    issues.push({
      level: 'error',
      code: 'asset.google-display-localization-required',
      scope: 'asset',
      message: 'google-display packages should localize remote assets into the ZIP instead of shipping remote references.',
    });
  }

  if (bundledAssetCount > 0 && !filePaths.includes('remote-fetch-plan.json')) {
    issues.push({
      level: 'warning',
      code: 'asset.missing-remote-fetch-plan',
      scope: 'asset',
      targetId: 'remote-fetch-plan.json',
      message: 'Bundle localizes remote assets but does not emit a remote-fetch-plan.json describing pending binary materialization.',
    });
  }

  if (bundledAssetCount > 0) {
    if (materializedAssets.length !== bundledAssetCount) {
      issues.push({
        level: 'warning',
        code: 'asset.bundle-materialization-pending',
        scope: 'asset',
        message: 'Bundle rewrites assets to local paths, but binary asset files are not yet materialized inside the ZIP.',
      });
      if (clickTagChannel) {
        issues.push({
          level: 'error',
          code: 'asset.clicktag-channel-materialization-required',
          scope: 'asset',
          message: `${bundle.channel} package still has pending localized assets. Run the resolved ZIP flow before handoff.`,
        });
      }
    }
  }

  if (totalBytes > 1024 * 1024 * 2) {
    issues.push({
      level: 'warning',
      code: 'bundle.large-size',
      scope: 'bundle',
      message: `Bundle size is ${Math.round(totalBytes / 1024)} KB. Large packages can create ad-hosting friction.`,
    });
  }

  const iabInitialLoadLimits: Partial<Record<ExportBundle['channel'], number>> = {
    'google-display': 150 * 1024,
    'gam-html5': 150 * 1024,
    'generic-html5': 150 * 1024,
    mraid: 150 * 1024,
  };
  const iabTotalLimits: Partial<Record<ExportBundle['channel'], number>> = {
    'google-display': 300 * 1024,
    'gam-html5': 300 * 1024,
    'generic-html5': 2 * 1024 * 1024,
    mraid: 500 * 1024,
    'meta-story': 5 * 1024 * 1024,
    'tiktok-vertical': 5 * 1024 * 1024,
  };
  const initialLoadBytes = packageMetrics.htmlBytes + packageMetrics.javascriptBytes;
  const initialLoadLimit = iabInitialLoadLimits[bundle.channel];
  const totalLimit = iabTotalLimits[bundle.channel];

  if (initialLoadLimit != null && initialLoadBytes > initialLoadLimit) {
    issues.push({
      level: 'warning',
      code: 'bundle.iab-initial-load-warning',
      scope: 'bundle',
      message: `Initial load (HTML + JS) is ${Math.round(initialLoadBytes / 1024)} KB, above the IAB recommended ${Math.round(initialLoadLimit / 1024)} KB. Consider deferring assets to polite load.`,
    });
  }
  if (totalLimit != null && packageMetrics.totalBytes > totalLimit) {
    issues.push({
      level: 'warning',
      code: 'bundle.iab-total-size-warning',
      scope: 'bundle',
      message: `Total bundle is ${Math.round(packageMetrics.totalBytes / 1024)} KB, above the recommended ${Math.round(totalLimit / 1024)} KB budget for ${bundle.channel}.`,
    });
  }

  if (mraidChannel && portableProject) {
    if (mraidAdapter) {
      issues.push({
        level: 'warning',
        code: 'runtime.mraid-placement-review',
        scope: 'runtime',
        targetId: mraidAdapter.mraid.expectedHost.placementType,
        message: `MRAID package expects ${mraidAdapter.mraid.expectedHost.placementType} host placement.`,
      });
      if (mraidAdapter.mraid.requiredHostFeatures.location) {
        issues.push({
          level: 'warning',
          code: 'runtime.mraid-location-host-required',
          scope: 'runtime',
          targetId: 'location',
          message: 'MRAID package requires host support for location APIs.',
        });
      }
    }
    getMraidProjectCompatibility(portableProject).forEach((item) => {
      issues.push({
        level: item.level === 'blocked' ? 'error' : 'warning',
        code: item.level === 'blocked' ? 'widget.mraid-blocked-module' : 'widget.mraid-review-module',
        scope: 'runtime',
        targetId: item.widgetId ?? item.type,
        message: item.message,
      });
    });
  }

  return issues;
}
