export { widgetReducer } from './widgets';
