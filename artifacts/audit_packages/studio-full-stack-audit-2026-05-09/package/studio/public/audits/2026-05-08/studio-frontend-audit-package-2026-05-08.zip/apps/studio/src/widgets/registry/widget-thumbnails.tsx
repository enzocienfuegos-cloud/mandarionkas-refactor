type Category = 'content' | 'media' | 'interactive' | 'layout';

function ThumbFrame({
  background,
  children,
}: {
  background: string;
  children: JSX.Element | JSX.Element[];
}): JSX.Element {
  return (
    <svg viewBox="0 0 160 100" aria-hidden="true" className="widget-thumb-svg">
      <rect x="0" y="0" width="160" height="100" rx="18" fill={background} />
      {children}
    </svg>
  );
}

export function PlaceholderThumb({ category }: { category: Category }): JSX.Element {
  const palette = {
    content: { bg: '#1f2937', fg: '#f8fafc', accent: '#f59e0b' },
    media: { bg: '#0f172a', fg: '#dbeafe', accent: '#38bdf8' },
    interactive: { bg: '#172033', fg: '#f8fafc', accent: '#22c55e' },
    layout: { bg: '#241b34', fg: '#f5f3ff', accent: '#a78bfa' },
  }[category];

  return (
    <ThumbFrame background={palette.bg}>
      <rect x="16" y="18" width="128" height="64" rx="14" fill="rgba(255,255,255,0.06)" stroke="rgba(255,255,255,0.1)" />
      <rect x="30" y="32" width="48" height="36" rx="10" fill={palette.accent} opacity="0.9" />
      <rect x="88" y="34" width="38" height="8" rx="4" fill={palette.fg} opacity="0.88" />
      <rect x="88" y="48" width="28" height="6" rx="3" fill={palette.fg} opacity="0.5" />
      <rect x="88" y="60" width="20" height="6" rx="3" fill={palette.fg} opacity="0.32" />
    </ThumbFrame>
  );
}

export function ImageThumb(): JSX.Element {
  return (
    <ThumbFrame background="#0f2742">
      <rect x="16" y="16" width="128" height="68" rx="16" fill="#e0f2fe" opacity="0.18" />
      <rect x="24" y="24" width="112" height="52" rx="12" fill="#0f766e" opacity="0.26" />
      <circle cx="48" cy="40" r="8" fill="#fef08a" />
      <path d="M30 72L62 46L80 60L98 42L130 72H30Z" fill="#dbeafe" opacity="0.95" />
    </ThumbFrame>
  );
}

export function HeroImageThumb(): JSX.Element {
  return (
    <ThumbFrame background="#123b63">
      <rect x="18" y="18" width="124" height="64" rx="18" fill="#082f49" opacity="0.58" />
      <path d="M26 74L60 40L84 56L106 34L134 74H26Z" fill="#e0f2fe" opacity="0.9" />
      <rect x="26" y="26" width="46" height="10" rx="5" fill="#ffffff" opacity="0.88" />
    </ThumbFrame>
  );
}

export function TextThumb(): JSX.Element {
  return (
    <ThumbFrame background="#111827">
      <rect x="22" y="22" width="116" height="56" rx="14" fill="rgba(255,255,255,0.05)" />
      <rect x="30" y="30" width="78" height="10" rx="5" fill="#f8fafc" />
      <rect x="30" y="46" width="96" height="7" rx="3.5" fill="#f8fafc" opacity="0.72" />
      <rect x="30" y="58" width="88" height="7" rx="3.5" fill="#f8fafc" opacity="0.48" />
    </ThumbFrame>
  );
}

export function CtaThumb(): JSX.Element {
  return (
    <ThumbFrame background="#1a1f2b">
      <rect x="26" y="24" width="108" height="18" rx="9" fill="#f8fafc" opacity="0.24" />
      <rect x="38" y="56" width="84" height="22" rx="11" fill="#f59e0b" />
      <rect x="56" y="63" width="48" height="8" rx="4" fill="#111827" opacity="0.88" />
    </ThumbFrame>
  );
}

export function VideoThumb(): JSX.Element {
  return (
    <ThumbFrame background="#020617">
      <rect x="20" y="18" width="120" height="64" rx="16" fill="#0f172a" stroke="rgba(255,255,255,0.12)" />
      <circle cx="80" cy="50" r="17" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.24)" />
      <path d="M74 40L92 50L74 60V40Z" fill="#f8fafc" />
      <rect x="28" y="72" width="84" height="4" rx="2" fill="#f8fafc" opacity="0.3" />
      <rect x="28" y="72" width="30" height="4" rx="2" fill="#f59e0b" />
    </ThumbFrame>
  );
}

export function CarouselThumb(): JSX.Element {
  return (
    <ThumbFrame background="#18222d">
      <rect x="16" y="20" width="54" height="60" rx="12" fill="#fb7185" opacity="0.88" />
      <rect x="53" y="20" width="54" height="60" rx="12" fill="#f59e0b" opacity="0.82" />
      <rect x="90" y="20" width="54" height="60" rx="12" fill="#22c55e" opacity="0.76" />
      <circle cx="78" cy="88" r="3" fill="#f8fafc" opacity="0.9" />
      <circle cx="86" cy="88" r="3" fill="#f8fafc" opacity="0.42" />
      <circle cx="94" cy="88" r="3" fill="#f8fafc" opacity="0.42" />
    </ThumbFrame>
  );
}

export function StoryThumb(): JSX.Element {
  return (
    <ThumbFrame background="#09090b">
      <rect x="52" y="10" width="56" height="80" rx="20" fill="#111827" stroke="rgba(255,255,255,0.16)" />
      <rect x="58" y="16" width="44" height="4" rx="2" fill="#f8fafc" opacity="0.8" />
      <rect x="60" y="28" width="40" height="48" rx="14" fill="#ec4899" opacity="0.65" />
      <circle cx="70" cy="28" r="8" fill="#f59e0b" />
      <rect x="66" y="80" width="28" height="4" rx="2" fill="#f8fafc" opacity="0.62" />
    </ThumbFrame>
  );
}

export function SocialCarouselThumb(): JSX.Element {
  return (
    <ThumbFrame background="#f8fafc">
      <rect x="20" y="18" width="120" height="64" rx="14" fill="#ffffff" stroke="#cbd5e1" />
      <circle cx="34" cy="30" r="7" fill="#1877f2" />
      <rect x="46" y="24" width="34" height="6" rx="3" fill="#0f172a" opacity="0.78" />
      <rect x="26" y="42" width="34" height="28" rx="8" fill="#f59e0b" opacity="0.82" />
      <rect x="64" y="42" width="34" height="28" rx="8" fill="#22c55e" opacity="0.8" />
      <rect x="102" y="42" width="18" height="28" rx="8" fill="#0ea5e9" opacity="0.74" />
    </ThumbFrame>
  );
}

export function TeadsLayout1Thumb(): JSX.Element {
  return (
    <ThumbFrame background="#ffffff">
      <rect x="22" y="18" width="116" height="64" rx="14" fill="#ffffff" stroke="#dbe4ec" />
      <circle cx="36" cy="30" r="7" fill="#0f172a" opacity="0.84" />
      <rect x="48" y="24" width="42" height="6" rx="3" fill="#0f172a" opacity="0.72" />
      <rect x="30" y="40" width="100" height="22" rx="10" fill="#cbd5e1" />
      <rect x="30" y="66" width="58" height="8" rx="4" fill="#0f172a" opacity="0.22" />
      <rect x="96" y="64" width="28" height="12" rx="6" fill="#e2e8f0" />
    </ThumbFrame>
  );
}

export function TeadsLayout2Thumb(): JSX.Element {
  return (
    <ThumbFrame background="#ffffff">
      <rect x="22" y="18" width="116" height="64" rx="14" fill="#ffffff" stroke="#dbe4ec" />
      <rect x="30" y="28" width="100" height="26" rx="10" fill="#cbd5e1" />
      <rect x="30" y="58" width="100" height="14" rx="7" fill="#1877f2" />
      <rect x="42" y="62" width="34" height="6" rx="3" fill="#ffffff" opacity="0.92" />
    </ThumbFrame>
  );
}

export function MapThumb(): JSX.Element {
  return (
    <ThumbFrame background="#dbeafe">
      <rect x="20" y="18" width="120" height="64" rx="16" fill="#eff6ff" stroke="#bfdbfe" />
      <path d="M20 54H140" stroke="#93c5fd" strokeWidth="4" opacity="0.65" />
      <path d="M56 18V82" stroke="#93c5fd" strokeWidth="4" opacity="0.45" />
      <path d="M100 18V82" stroke="#93c5fd" strokeWidth="4" opacity="0.45" />
      <path d="M82 34C82 26.82 76.18 21 69 21C61.82 21 56 26.82 56 34C56 45 69 56 69 56C69 56 82 45 82 34Z" fill="#ef4444" />
      <circle cx="69" cy="34" r="4.5" fill="#ffffff" />
      <rect x="94" y="28" width="28" height="22" rx="8" fill="#22c55e" opacity="0.9" />
      <rect x="98" y="35" width="20" height="6" rx="3" fill="#ffffff" opacity="0.88" />
    </ThumbFrame>
  );
}
