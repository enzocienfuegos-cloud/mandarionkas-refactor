import { useRef, useState } from 'react';
import type { WidgetNode } from '../../domain/document/types';
import type { RenderContext } from '../../canvas/stage/render-context';
import { StudioIcon, StudioIcons } from '../../shared/ui/icons';
import { renderCollapsedIfNeeded } from './shared-styles';
import { ModuleMediaPlaceholder } from './render-icons';

// ─── Types ────────────────────────────────────────────────────────────────────

interface CarouselSlide {
  src: string;
  kind: 'image' | 'video';
  title: string;
  description: string;
}

function getSlides(node: WidgetNode): CarouselSlide[] {
  const count = Math.min(5, Math.max(1, Number(node.props.slideCount ?? 3)));
  return Array.from({ length: count }, (_, i) => {
    const n = i + 1;
    return {
      src: String(node.props[`slide${n}Src`] ?? '').trim(),
      kind: String(node.props[`slide${n}Kind`] ?? 'image') === 'video' ? 'video' : 'image',
      title: String(node.props[`slide${n}Title`] ?? `Product ${n}`),
      description: String(node.props[`slide${n}Description`] ?? ''),
    };
  });
}

// ─── Facebook-style header ────────────────────────────────────────────────────

function MetaHeader({ node }: { node: WidgetNode }) {
  const avatarSrc = String(node.props.brandAvatarSrc ?? '').trim();
  const brandName = String(node.props.brandName ?? 'Brand Name');
  const sponsored = String(node.props.sponsoredLabel ?? 'Sponsored');
  const primaryText = String(node.props.primaryText ?? '');

  return (
    <div style={{ padding: '10px 12px 6px', borderBottom: '1px solid #e4e6eb', flexShrink: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: primaryText ? 6 : 0 }}>
        <div style={{
          width: 36, height: 36, borderRadius: '50%', overflow: 'hidden', flexShrink: 0,
          background: 'linear-gradient(135deg,#1877f2,#42b883)',
        }}>
          {avatarSrc
            ? <img src={avatarSrc} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            : null}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontSize: 13, fontWeight: 600, color: '#050505',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          }}>{brandName}</div>
          <div style={{ fontSize: 11, color: '#65676b', fontFamily: 'sans-serif' }}>{sponsored} · 🌐</div>
        </div>
        <span style={{ color: '#65676b', fontSize: 18, cursor: 'pointer', padding: '0 4px' }}>···</span>
      </div>
      {primaryText && (
        <div style={{
          fontSize: 13, color: '#050505', lineHeight: 1.4,
          fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
          marginBottom: 4,
          overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical',
        }}>{primaryText}</div>
      )}
    </div>
  );
}

// ─── Single card ──────────────────────────────────────────────────────────────

function CarouselCard({ slide, ctaLabel, isActive, cardW, imageH, cardRadius }: {
  slide: CarouselSlide;
  ctaLabel: string;
  isActive: boolean;
  cardW: number;
  imageH: number;
  cardRadius: number;
}) {
  return (
    <div style={{
      flexShrink: 0,
      width: cardW,
      borderRadius: cardRadius,
      overflow: 'hidden',
      border: '1px solid #e4e6eb',
      background: '#fff',
      opacity: isActive ? 1 : 0.72,
      transition: 'opacity 0.2s',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* Media — height controlled by imageH prop */}
      <div style={{
        width: '100%', height: imageH,
        background: '#e4e6eb', overflow: 'hidden',
        position: 'relative', flexShrink: 0,
      }}>
        {slide.src
          ? slide.kind === 'video'
            ? <video src={slide.src} muted playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            : <img src={slide.src} alt={slide.title} draggable={false} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          : <ModuleMediaPlaceholder kind={slide.kind} label={slide.kind === 'video' ? 'Video' : 'Image'} color="#b0b8c1" iconSize={20} />
        }
      </div>

      {/* Card footer — title + CTA */}
      <div style={{
        padding: '8px 10px',
        display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', gap: 6,
        flex: 1,
      }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontSize: 12, fontWeight: 600, color: '#050505',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          }}>{slide.title}</div>
          {slide.description && (
            <div style={{
              fontSize: 11, color: '#65676b', fontFamily: 'sans-serif',
              whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
            }}>{slide.description}</div>
          )}
        </div>
        <div style={{
          flexShrink: 0, padding: '5px 10px',
          border: '1px solid #d0d5dd', borderRadius: 6,
          fontSize: 12, fontWeight: 600, color: '#050505',
          fontFamily: 'sans-serif', cursor: 'pointer', whiteSpace: 'nowrap',
          background: '#f0f2f5',
        }}>
          {ctaLabel || 'Shop Now'}
        </div>
      </div>
    </div>
  );
}

// ─── Main renderer ────────────────────────────────────────────────────────────

function MetaCarouselRenderer({ node, ctx }: { node: WidgetNode; ctx: RenderContext }) {
  const slides = getSlides(node);
  const ctaLabel = String(node.props.ctaLabel ?? 'Shop Now');
  const [activeIndex, setActiveIndex] = useState(0);
  const swipeStartX = useRef<number | null>(null);

  // ── Sizing from props — all adjustable from inspector ──────────────────────
  // cardWidthPct: card width as % of the widget frame width (default 75%)
  const cardWidthPct = Math.min(100, Math.max(30, Number(node.props.cardWidthPct ?? 75)));
  // imageHeightPct: image area as % of the card area height (default 60%)
  const imageHeightPct = Math.min(90, Math.max(20, Number(node.props.imageHeightPct ?? 60)));
  // cardRadius: border-radius of cards
  const cardRadius = Math.max(0, Number(node.props.cardRadius ?? 8));

  // Derived pixel values from the frame
  const frameW = node.frame.width;
  const SIDE_PAD = 12;
  const GAP = Math.max(4, Number(node.props.cardGap ?? 10));
  const cardW = Math.round((frameW - SIDE_PAD * 2) * (cardWidthPct / 100));

  // Image height is a % of the available carousel track area.
  // We estimate header (~80px) + dots (~22px) + footer (~34px) = ~136px reserved.
  // The rest is the carousel zone. imageHeightPct applies to that zone minus card footer (~42px).
  const RESERVED_PX = 136;
  const carouselH = Math.max(80, node.frame.height - RESERVED_PX);
  const CARD_FOOTER_H = 42;
  const imageH = Math.round((carouselH - CARD_FOOTER_H) * (imageHeightPct / 100));

  const maxIndex = slides.length - 1;

  function goTo(idx: number) {
    setActiveIndex(Math.max(0, Math.min(maxIndex, idx)));
  }

  function onPointerDown(e: React.PointerEvent) {
    swipeStartX.current = e.clientX;
  }
  function onPointerUp(e: React.PointerEvent) {
    if (swipeStartX.current === null) return;
    const delta = e.clientX - swipeStartX.current;
    swipeStartX.current = null;
    if (Math.abs(delta) < 20) return;
    if (delta < 0) goTo(activeIndex + 1);
    else goTo(activeIndex - 1);
  }

  const translateX = activeIndex * (cardW + GAP);

  return (
    <div style={{
      background: '#fff',
      borderRadius: 8,
      overflow: 'hidden',
      width: '100%',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      boxShadow: '0 1px 3px rgba(0,0,0,0.12)',
    }}>
      {/* Header */}
      <MetaHeader node={node} />

      {/* Carousel track — flex: 1 fills remaining space */}
      <div
        style={{ flex: 1, overflow: 'hidden', position: 'relative', cursor: 'grab', userSelect: 'none' }}
        onPointerDown={onPointerDown}
        onPointerUp={onPointerUp}
      >
        <div
          style={{
            display: 'flex',
            gap: GAP,
            paddingLeft: SIDE_PAD,
            paddingRight: SIDE_PAD,
            paddingTop: 8,
            paddingBottom: 8,
            height: '100%',
            boxSizing: 'border-box',
            transform: `translateX(-${translateX}px)`,
            transition: 'transform 0.3s cubic-bezier(.25,.46,.45,.94)',
          }}
        >
          {slides.map((slide, i) => (
            <CarouselCard
              key={i}
              slide={slide}
              ctaLabel={ctaLabel}
              isActive={i === activeIndex}
              cardW={cardW}
              imageH={imageH}
              cardRadius={cardRadius}
            />
          ))}
        </div>

        {/* Arrow prev */}
        {activeIndex > 0 && (
          <button
            type="button"
            onClick={() => goTo(activeIndex - 1)}
            style={{
              position: 'absolute', left: 4, top: '50%', transform: 'translateY(-50%)',
              width: 28, height: 28, borderRadius: '50%', border: '1px solid #e4e6eb',
              background: '#fff', boxShadow: '0 2px 6px rgba(0,0,0,0.15)',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 16, color: '#050505', zIndex: 2, lineHeight: 1,
            }}
            aria-label="Previous slide"
          >
            <StudioIcon icon={StudioIcons.chevronLeft} size={16} strokeWidth={2.4} />
          </button>
        )}

        {/* Arrow next */}
        {activeIndex < maxIndex && (
          <button
            type="button"
            onClick={() => goTo(activeIndex + 1)}
            style={{
              position: 'absolute', right: 4, top: '50%', transform: 'translateY(-50%)',
              width: 28, height: 28, borderRadius: '50%', border: '1px solid #e4e6eb',
              background: '#fff', boxShadow: '0 2px 6px rgba(0,0,0,0.15)',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 16, color: '#050505', zIndex: 2, lineHeight: 1,
            }}
            aria-label="Next slide"
          >
            <StudioIcon icon={StudioIcons.chevronRight} size={16} strokeWidth={2.4} />
          </button>
        )}
      </div>

      {/* Dot indicators */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 4, padding: '4px 0 6px', flexShrink: 0 }}>
        {slides.map((_, i) => (
          <div
            key={i}
            onClick={() => goTo(i)}
            style={{
              width: i === activeIndex ? 16 : 6, height: 6, borderRadius: 3,
              background: i === activeIndex ? '#1877f2' : '#c8ccd0',
              cursor: 'pointer', transition: 'all 0.2s',
            }}
          />
        ))}
      </div>

      {/* Like / Comment / Share */}
      <div style={{
        borderTop: '1px solid #e4e6eb', padding: '6px 12px',
        display: 'flex', flexShrink: 0,
      }}>
        {['👍 Like', '💬 Comment', '↗ Share'].map((action) => (
          <div key={action} style={{
            flex: 1, textAlign: 'center', fontSize: 12, fontWeight: 600,
            color: '#65676b', padding: '4px 0', cursor: 'pointer',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
          }}>{action}</div>
        ))}
      </div>
    </div>
  );
}

export function renderMetaCarouselStage(node: WidgetNode, ctx: RenderContext): JSX.Element {
  const collapsed = renderCollapsedIfNeeded(node, ctx);
  if (collapsed) return collapsed;
  return <MetaCarouselRenderer node={node} ctx={ctx} />;
}
